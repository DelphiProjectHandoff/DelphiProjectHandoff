﻿Delphi Project Handoff 0.2.1 experimental Windows Win32 build

Extract this folder to a writable local location and run DelphiProjectHandoff.exe.
This build opens maximized. Selection details on the right identifies the object
you double-click in the far-left list. Click Explain in the centre for behavior.
Read activity on the bottom status line. To read analysis gaps, click Learn the
project in the centre, then Coverage and troubleshooting in that tab's topic list.
Keep help, migrations and WebView2Loader.dll beside the application. Read the
Getting started page at launch, then Learn the project and Explain. The executable is
the validated Win32 Debug build. Microsoft WebView2 Runtime is required only for
embedded preview; no runtime installer is run automatically. Offline exported
HTML can also be inspected independently. LibreOffice and Python 3.13 with pypdf
are optional prerequisites for tools/export-pdf.ps1, not for normal analysis.

DPH reads an explicitly selected Delphi project without compiling or executing
it. Store each knowledge database outside its selected source tree. Copy a cache
with its adjacent .dphdb.views folder. Use Relocate verified source for an exact
source move; unrelated or changed inputs cannot claim identity continuity.

Read docs/Rework_Acceptance.txt, Rework_Requirements_Audit.txt and the guides
before relying on analysis. This version adds guided lessons, source-based object
explanations, callback traces, labeled/collapsed procedure diagrams, imported PNG
screenshots and richer offline publication. Form designs remain approximate.
The prior blanket WP7 completion claim is withdrawn. The pinned
large reference remains partial. Independent first-time-programmer acceptance
and agreed release performance budgets are outstanding. This is an experimental
distribution, not a claim that every formal product acceptance gate has passed.

Validate an export with DPH.ValidateHandoff.exe <bundle> <trusted fingerprint>.
The optional --allow-stale flag permits integrity checks on historical/partial
exports while retaining their stale status. Unsigned hashes are not signatures.

Atlas, external AI/translation and runtime instrumentation remain disabled.
The converter reference corpus, knowledge databases, source snapshots and owner
AGENTS.md are not included in this binary distribution.
