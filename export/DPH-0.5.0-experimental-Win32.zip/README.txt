Delphi Project Handoff
Experimental Windows desktop learning application

1. Extract this whole folder to a writable local location.
2. Double-click DelphiProjectHandoff.exe.
3. Click Try practice example for prepared lessons and a worked learning path.
4. Use Learn the project, Learn a task and Learning library in the selector.
5. Open docs\guides\Run_And_Test.txt for a repeatable first-session check.

The User Guide is in docs\pdf\DPH_User_Guide.pdf and docs\guides as an
editable document. The Engineering Guide covers building and maintaining DPH.
Keep all supplied files together. Microsoft WebView2 Runtime is needed for
embedded pages; its supplied loader is a separate file.

DPH reads source without changing or running the selected application.
Supplied tasks and answers remain attributed and may require review.
Form designs are reconstructions; Screenshots contains supplied images.
This package contains no owner lesson databases or private documents.
