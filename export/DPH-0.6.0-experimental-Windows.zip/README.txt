﻿Delphi Project Handoff
Experimental Windows desktop learning application

1. Extract this whole folder to a writable local location.
2. On 64-bit Windows, open Win64 and double-click DelphiProjectHandoff.exe.
   Use the Win32 copy only when you need the 32-bit edition.
3. Click Open application and select the Delphi project you want to learn.
4. Use Learn the project, Learning library, Project map, Screenshots and Graphs.
5. Screenshots contains blank screen images generated inside DPH from that
   project's .fmx and .dfm form files. Runtime appearance can differ.

The included guides and HTML help describe the app-specific learning route.
Keep all supplied files together. Microsoft WebView2 Runtime is needed for
embedded pages; its supplied loader is a separate file.

DPH reads source and project-local documents without changing or running the
selected application. It generates empty design views from form definitions.
This package contains no owner lesson databases or private documents.
