﻿Delphi Project Handoff
Experimental Windows desktop handoff application - version 0.8.0.13

1. Extract this whole folder to a writable local location.
2. On 64-bit Windows, open Win64 and double-click DelphiProjectHandoff.exe.
   Use the Win32 copy only when you need the 32-bit edition.
3. Click Open application and select a Delphi .dproj, .dpr, or .groupproj.
   DPH reads the project; it does not compile or run the selected application.
4. Start with Handoff dossier for the captured purpose evidence, startup
   forms, commands, data candidates, and questions. Use Learning library,
   Project map, Screenshots, and Application diagrams for deeper inspection.
   Use Rescan project after attached source files change. The dossier also
   lists captured build paths, component leads, and database templates.
5. Screenshots reconstruct saved controls from .fmx and .dfm form files on
   demand and open at 90 percent zoom. They are not captures of the running
   application; custom painting and runtime data may differ.
6. Choose your language from the selector in the main header. All 35 language
   packs work offline and remain beside each Windows edition.
   The experimental English-to-German project-text model is also bundled in
   Localization\OfflineTranslation and runs without Internet access.
7. A new capture stays temporary. Click Save project at any time to keep it.
   When closing DPH or opening another project, choose Yes to save it as a
   .dphdb, No to discard it, or Cancel
   to continue. Keep a saved .dphdb and its adjacent .dphdb.views folder
   together. Use Open saved project to restore them later.

A centered progress window shows the current step and percentage during a new
capture. The Learning library reads guides from the selected project's docs folder and
the project's README. The Read public websites checkbox is off by default.
Leave it off for fully offline use. When enabled, eligible public HTTPS pages
from that project's sitemap or documents may appear in the Learning library.

The included guides and HTML help describe the app-specific learning route.
Keep all supplied files together. Microsoft WebView2 Runtime is needed for
embedded pages; its supplied loader is a separate file.

DPH reads source and project-local documents without changing or running the
selected application. It generates empty design views from form definitions.
This package contains no owner lesson databases or private documents.
