DELPHI PROJECT HANDOFF - EDITABLE SOURCE DISTRIBUTION

This archive contains the Delphi application source, editable FMX forms,
project and resource files, database migrations, the local HTML help, graphics,
all 35 offline language packs, and the bundled build dependencies. It contains no personal .dphdb databases,
Git history, or compiled DPH executable.

TO BUILD
1. Extract the entire ZIP into a writable local folder. Do not build in the ZIP.
2. Open DelphiProjectHandoff.dproj in RAD Studio 37 or later.
   To edit the form in the designer, install the supplied DAT FMX design package
   using export\DAT-component-kit\DelphiProjectHandoff\README.txt.
3. Select Win64 or Win32 and the Release configuration; then choose Build.
4. Find the executable in bin\Win64\Release or bin\Win32\Release. Keep the
   corresponding WebView2Loader.dll beside it. The project copies that loader
   automatically after a successful build.
5. Run the executable from the extracted project folder. Keep migrations,
   help, images and icons, and Localization in that folder. See docs\guides\Run_And_Test.txt
   for the application's first-use and validation steps.

The Microsoft WebView2 Runtime is required for embedded HTML learning views.
The selected Delphi application is read as input; DPH does not run or modify it.
The included third-party dependency folders contain their own license files.

SHA256.txt lists every packaged source file and its SHA-256 digest. The
DelphiProjectHandoff.res file is part of the source release because the
DelphiProjectHandoff.dpr file references it.