# Delphi Project Handoff

Delphi Project Handoff (DPH) helps a beginner learn one unfamiliar Delphi application: what it does, how to use its screens, what inputs mean, how an action reaches its operation, and how to recognize a result. DPH reads selected source without changing, compiling or running that application.

## Run and learn

1. Extract the desktop package into a writable local folder and double-click `DelphiProjectHandoff.exe`.
2. Click **Try practice example**. The supplied order-calculation example includes four ordered First day tasks, fourteen teaching explanations, worked totals, safe error recovery and two actual native pictures.
3. Use **Learn a task** for actions and expected results, **Learning library** for meanings and examples, and **Learn the project** to follow screens and source connections.
4. When ready, click **Choose application** and select your own Delphi project or project group. Keep its `.dphdb` outside the selected source tree, together with its adjacent `.dphdb.views` folder.

Read [Run and test](docs/guides/Run_And_Test.txt) for explicit first-session directions. The [User Guide](docs/pdf/DPH_User_Guide.pdf) covers reading and preparing lessons. The [Engineering Guide](docs/pdf/DPH_Engineering_Guide.pdf) covers the architecture, build, validation and deployment.

## Teaching features

- Application purpose, a beginner learning route and plain Delphi terms.
- Screen and field meanings, worked examples, input limits, safe help and practice answers.
- Ordered task steps, role filters, learning paths and personal revision-specific checked-step progress.
- Source-linked action explanations with optional deeper detail.
- Attributed FAQs, error recovery, business rules, settings, dependencies and output explanations.
- Real supplied pictures and sample outputs with anchored numbered callouts. Source-based form reconstructions remain clearly labeled.
- Search, business glossary, saved knowledge and shared offline lessons from the same records.

Preparing a lesson cannot establish an unwritten business fact. A knowledgeable contributor supplies that information; DPH preserves attribution, unanswered points and review status. Checked steps record the learner's checks, not proof of mastery or a recorded application run.

## Build and validate

Use the configured RAD Studio toolchain from an elevated developer prompt. `tools\build-wp0.cmd` builds DPH and verifies the serialized FMX controls. `tools\build-practice.cmd` exercises the supplied beginner route using a new disposable destination. Detailed test directions are in [Developer test directions](docs/guides/Developer_Test_Directions.txt).

Forms and ordinary controls remain editable in the IDE. The selected application is a read-only input. Runtime observation, live service access and selected-project execution are not part of passive discovery.

## Current scope

[The learning reconciliation](docs/Learning_Requirements_Reconciliation.txt) records all 533 original requirement dispositions; its CSV and JSON retain each original status, limitation and remaining work. The revised learning contract supersedes dedicated enterprise administration, specialist analysis expansion and agent infrastructure. A scope decision does not claim that an original technical requirement was implemented. The historical ledger remains unchanged.

Independent first-time learner acceptance is reported separately from software validation. The converter reference is passive test input and is never a DPH build or runtime dependency.
