program DPH.Tests.DatabaseTransactions;
{$APPTYPE CONSOLE}
uses System.SysUtils,System.Classes,System.IOUtils,System.JSON,System.Hash,System.StrUtils,System.UITypes,
  FMX.Forms,FMX.Graphics,DPH.Project.Analysis,DPH.Analysis.Model,DPH.Analysis.Symbols,
  DPH.Workspace.Keyboard,DPH.Workspace.Model,DPH.Workspace.DatabaseConnections,DPH.UI.Main,DPH.Workspace.Catalog,
  DPH.Storage.Database,DPH.Storage.Types,DPH.Analysis.Persistence;
var Root,Work,Fixture,Text,Catalog,CatalogHash,SourceHash,Database:string;I,Checks:Integer;
    Analyzer:TDPHAnalyzer;Semantic:TDPHSemanticAnalyzer;Scan:TDPHScan;Graph:TDPHSemanticGraph;
    View,Reopened:TDPHWorkspaceView;Document,Report,Row,Link,Log:TJSONObject;Value:TJSONValue;
    Form:TDPHMainForm;Bitmap:TBitmap;Input:TStringStream;Binary:TMemoryStream;
    Store:TDPHKnowledgeStore;Config,Generation:Int64;
procedure Check(OK:Boolean;const MessageText:string);
begin if not OK then raise Exception.Create('FAIL '+MessageText);Inc(Checks);Writeln('PASS ',Checks,': ',MessageText);Flush(Output);end;
function Find(const Name:string):TJSONObject;
var V:TJSONValue;
begin Result:=nil;for V in Report.GetValue<TJSONArray>('rows') do if V.GetValue<string>('name')=Name then Exit(V as TJSONObject);end;
function Reference(const Name,PropertyName:string):TJSONObject;
var V:TJSONValue;
begin Result:=nil;for V in Find(Name).GetValue<TJSONArray>('links') do if SameText(V.GetValue<string>('property'),PropertyName) then Exit(V as TJSONObject);end;
function TxRow(const Routine,Method:string):TJSONObject;
var V:TJSONValue;
begin Result:=nil;for V in Report.GetValue<TJSONArray>('rows') do
 if (V.GetValue<string>('role')='transaction operation') and (V.GetValue<string>('name')=Method) and V.GetValue<string>('path').Contains('.'+Routine+' /') then Exit(V as TJSONObject);
end;
function HasPath(ARow:TJSONObject;const Target,Kind:string):Boolean;
var V:TJSONValue;
begin Result:=False;for V in ARow.GetValue<TJSONArray>('transaction_paths') do
 if V.GetValue<string>('target').Contains(Target) and V.GetValue<string>('path_kind').Contains(Kind) then Exit(True);
end;
procedure Render(const Name:string);
begin Application.ProcessMessages;Bitmap:=TBitmap.Create(Form.ClientWidth,Form.ClientHeight);
try if Bitmap.Canvas.BeginScene then try Form.PaintTo(Bitmap.Canvas);finally Bitmap.Canvas.EndScene;end;
Bitmap.SaveToFile(TPath.Combine(Root,'docs\'+Name));finally Bitmap.Free;end;end;
begin
 Application.Initialize;
 try
 Root:=TPath.GetFullPath(ParamStr(1));Work:=TPath.Combine(Root,'bin\database-transactions-validation');
 if TDirectory.Exists(Work) then TDirectory.Delete(Work,True);
 Fixture:=TPath.Combine(Work,'source');TDirectory.CreateDirectory(Fixture);
 TFile.WriteAllText(TPath.Combine(Fixture,'Connections.dpr'),'program Connections; uses Main, Remote, Touch, BinaryDB, Shadow, TxTrace, TxShadow; begin end.',TEncoding.UTF8);
 TFile.WriteAllText(TPath.Combine(Fixture,'Main.pas'),String.Join(sLineBreak,[
 'unit Main; interface uses Data.DB, FireDAC.Comp.Client; type TCustomRecords = class(TDataSet); TOrdinary = class procedure Delete; end; TMainModule = class',' MainConnection: TFDConnection;',' Query: TFDQuery;',' Unserialized: TADOConnection;',' Records: TCustomRecords;',' OrdinaryObject: TOrdinary;',' procedure Work;',
 'end; implementation {$R *.dfm}', 'procedure TOrdinary.Delete; begin end;', 'procedure TMainModule.Work; var Local: TDataSet; begin', 'Query.Open; Query.Refresh; Query.First; Query.Next; Query.Locate(''CODE'', 1, []);', 'Query.Append; Query.Insert; Query.AppendRecord([1]); Query.InsertRecord([2]); Query.Edit; Query.Post; Query.Delete; Query.Cancel; Query.ApplyUpdates(0); Query.CancelUpdates;', 'Query.SQL.Text := ''SELECT a.CODE FROM A a JOIN B b ON a.CODE=b.CODE'';', 'Query.SQL.Text := ''INSERT INTO A(CODE) VALUES (1)'';', 'Query.SQL.Text := ''UPDATE A SET CODE=2'';', 'Query.SQL.Text := ''DELETE FROM A WHERE CODE=1'';', 'Query.SQL.Text := ''SELECT CODE FROM A; DELETE FROM A'';', 'Query.SQL.Text := BuildSQL;', 'Query.ExecSQL; Query.ExecSQL(''DELETE FROM A'');', 'Records.Delete; Local.Post; OrdinaryObject.Delete;', 'end; end.']),TEncoding.UTF8);
 TFile.WriteAllText(TPath.Combine(Fixture,'Shadow.pas'),String.Join(sLineBreak,[
 'unit Shadow; interface uses FireDAC.Comp.Client; type TFDQuery = class procedure Delete; end; procedure Work; implementation',
 'procedure TFDQuery.Delete; begin end; procedure Work; var Fake: TFDQuery; begin Fake.Delete; end; end.']),TEncoding.UTF8);
 TFile.WriteAllText(TPath.Combine(Fixture,'TxTrace.pas'),String.Join(sLineBreak,[
 'unit TxTrace; interface uses Data.DB, FireDAC.Comp.Client, Data.Win.ADODB, Data.SqlExpr, IBX.IBDatabase, Bde.DBTables;',
 'type TCustomConnection = class(TFDConnection) end; TTx = class',
 ' C, Other: TFDConnection; Tx: TFDTransaction; ADO: TADOConnection; SQLConn: TSQLConnection; IB: TIBTransaction; BDE: TDatabase; Q: TFDQuery; Flag: Boolean;',
 ' procedure Work; procedure Cleanup; procedure Branches; procedure Missing; procedure Cross; procedure Retain; procedure ADOWork; procedure SQLWork; procedure Derived; procedure BDEWork; procedure Ambiguous;',
 'end; implementation',
 'procedure TTx.Work; begin C.StartTransaction; try Q.ExecSQL; C.Commit; except C.Rollback; raise; end; end;',
 'procedure TTx.Cleanup; begin Tx.StartTransaction; try Q.Edit; if Flag then Exit; finally Tx.Rollback; end; end;',
 'procedure TTx.Branches; begin C.StartTransaction; if Flag then C.Commit else C.Rollback; end;',
 'procedure TTx.Missing; begin C.StartTransaction; Q.Refresh; end;',
 'procedure TTx.Cross; begin C.StartTransaction; Other.Commit; C.Rollback; end;',
 'procedure TTx.Retain; begin Tx.StartTransaction; Tx.CommitRetaining; Tx.RollbackRetaining; IB.StartTransaction; IB.CommitRetaining; IB.RollbackRetaining; IB.RollbackSavepoint(''SENSITIVE_SAVEPOINT_CANARY''); IB.Rollback; end;',
 'procedure TTx.ADOWork; var Level: Integer; begin Level := ADO.BeginTrans; ADO.CommitTrans; ADO.RollbackTrans; end;',
 'procedure TTx.SQLWork; begin SQLConn.BeginTransaction; SQLConn.CommitFreeAndNil(nil); SQLConn.RollbackIncompleteFreeAndNil(nil); end;',
 'procedure TTx.Derived; var Local: TCustomConnection; begin Local.StartTransaction; Local.Commit; end;',
 'procedure TTx.BDEWork; begin BDE.StartTransaction; BDE.Commit; BDE.Rollback; end;',
 'procedure TTx.Ambiguous; var Level: Integer; begin Level := ADO.BeginTrans() + ADO.BeginTrans(); end;',
 'end.']),TEncoding.UTF8);
 TFile.WriteAllText(TPath.Combine(Fixture,'TxShadow.pas'),String.Join(sLineBreak,[
 'unit TxShadow; interface uses FireDAC.Comp.Client; type TFDConnection = class procedure Commit; end; TOrdinary = class procedure Rollback; end;',
 'procedure Work; implementation procedure TFDConnection.Commit; begin end; procedure TOrdinary.Rollback; begin end;',
 'procedure Work; var Fake: TFDConnection; Ordinary: TOrdinary; begin Fake.Commit; Ordinary.Rollback; end; end.']),TEncoding.UTF8);
 for Text in ['Remote','Touch','BinaryDB'] do TFile.WriteAllText(TPath.Combine(Fixture,Text+'.pas'),'unit '+Text+'; interface implementation {$R *.'+IfThen(Text='Touch','fmx','dfm')+'} end.',TEncoding.UTF8);
 Text:=String.Join(sLineBreak,[
 'object MainModule: TMainModule',
 ' object MainConnection: TFDConnection','  ConnectionDefName = ''PrimaryDef''','  Connected = True','  LoginPrompt = False',
 '  Database = ''SENSITIVE_ENDPOINT_CANARY''','  Password = ''SENSITIVE_PASSWORD_CANARY''',
 '  DatabaseName = ''SENSITIVE_DATABASE_NAME_CANARY''',
 '  Params.Strings = (','    ''DriverID=FB''','    ''Port=3050''','    ''Database=SENSITIVE_DB_CANARY''',
 '    ''User_Name=SENSITIVE_USER_CANARY''','    ''PWD=SENSITIVE_PWD_CANARY''','    ''UnknownKey=SENSITIVE_UNKNOWN_CANARY'')',' end',
 ' object Query: TFDQuery','  Connection = MainConnection',
 '  object Amount: TCurrencyField','   FieldName = ''AMOUNT''','   Required = True','   ReadOnly = False','  end',
 '  object CodeA: TStringField','   FieldName = ''CODE''','  end',
 '  object CodeB: TStringField','   FieldName = ''CODE''','  end',' end',
 ' object AmountEdit: TDBEdit','  DataSource = Source','  DataField = ''amount''',' end',
 ' object CodeEdit: TDBEdit','  DataSource = Source','  DataField = ''CODE''',' end',
 ' object DynamicEdit: TDBEdit','  DataSource = Source','  DataField = ''RUNTIME_FIELD''',' end',
 ' object BrokenEdit: TDBEdit','  DataSource = NoSource','  DataField = ''AMOUNT''',' end',
 ' object NilEdit: TDBEdit','  DataSource = nil','  DataField = ''AMOUNT''',' end',
 ' object Lookup: TStringField','  LookupDataSet = Query','  FieldName = ''LOOKUP''',' end',
 ' object Source: TDataSource','  DataSet = Query',' end',
 ' object RemoteQuery: TADOQuery','  Connection = RemoteDM.RemoteConnection',' end',
 ' object Broken: TFDQuery','  Connection = MissingConnection',' end',
 ' object QuotedDatabase: TFDQuery','  Database = ''SENSITIVE_DATASET_DB_CANARY''',' end',
 ' object UnqualifiedRemote: TFDQuery','  Connection = RemoteConnection',' end',
 ' object Ordinary: TButton','  Caption = ''SENSITIVE_NON_DB_CANARY''',' end',
 ' object NilQuery: TFDQuery','  Connection = nil',' end',
 ' object WrongRole: TFDQuery','  Connection = Query',' end',
 ' object Expression: TFDQuery','  Connection = SENSITIVE_EXPRESSION_CANARY()',' end',
 ' object ADO: TADOConnection','  ConnectionString = ''Provider=MSDASQL;PWD=SENSITIVE_ADO_CANARY''',' end',
 ' object IB: TIBDatabase',' end',' object Tx: TIBTransaction','  DefaultDatabase = IB',' end',
 ' object IBQuery: TIBQuery','  Database = IB','  Transaction = Tx',' end',
 ' object Legacy: TDatabase','  DatabaseName = ''LogicalDB''','  SessionName = ''SharedSession''',' end',
 ' object LegacyQuery: TQuery','  DatabaseName = ''LogicalDB''',' end',
 ' object Session: TSession','  SessionName = ''SharedSession''',' end',
 ' object Nested: TPanel','  object NestedConnection: TFDConnection','  end',' end',
 ' object NestedQuery: TFDQuery','  Connection = Nested.NestedConnection',' end',
 ' object SelfQuery: TFDQuery','  Connection = Self.MainConnection',' end',
 ' object Duplicate: TFDConnection',' end',' object Duplicate: TFDConnection',' end',
 ' object Ambiguous: TFDQuery','  Connection = Duplicate',' end',
 ' object Custom: TCustomBusinessQuery','  Connection = MainConnection',' end',
 ' inherited InheritedQuery: TFDQuery',' end',
 ' object BadConfig: TFDConnection','  DriverID = ''SENSITIVE_DRIVER_CANARY()''','  Port = 70000',' end']);
 for I:=1 to 270 do Text:=Text+sLineBreak+' object Extra'+IntToStr(I)+': TFDQuery'+sLineBreak+'  Connection = MainConnection'+sLineBreak+' end';
 Text:=Text+sLineBreak+'end';TFile.WriteAllText(TPath.Combine(Fixture,'Main.dfm'),Text,TEncoding.UTF8);
 TFile.WriteAllText(TPath.Combine(Fixture,'Remote.dfm'),String.Join(sLineBreak,[
 'object RemoteDM: TDataModule',' object RemoteConnection: TADOConnection','  ConnectionDefName = ''PrimaryDef''',' end','end']),TEncoding.UTF8);
 TFile.WriteAllText(TPath.Combine(Fixture,'Touch.fmx'),String.Join(sLineBreak,[
 'object TouchForm: TForm',' object TouchConnection: TSQLConnection',' end',' object TouchQuery: TSQLQuery','  SQLConnection = TouchConnection','  object TouchID: TIntegerField','   FieldName = ''ID''','  end',' end',' object TouchSource: TBindSourceDB','  DataSet = TouchQuery',' end',' object TouchLink: TLinkControlToField','  DataSource = TouchSource','  FieldName = ''ID''','  Control = TouchEdit',' end',' object TouchEdit: TEdit',' end','end']),TEncoding.UTF8);
 Input:=TStringStream.Create(String.Join(sLineBreak,[
 'object BinaryModule: TDataModule',' object BinaryConnection: TFDConnection','  Password = ''SENSITIVE_BINARY_CANARY''',' end',
 ' object BinaryQuery: TFDQuery','  Connection = BinaryConnection','  object BinaryID: TIntegerField','   FieldName = ''ID''','  end',' end',' object BinarySource: TDataSource','  DataSet = BinaryQuery',' end',' object BinaryEdit: TDBEdit','  DataSource = BinarySource','  DataField = ''ID''',' end','end']));Binary:=TMemoryStream.Create;
 try ObjectTextToBinary(Input,Binary);Binary.SaveToFile(TPath.Combine(Fixture,'BinaryDB.dfm'));finally Binary.Free;Input.Free;end;
 SourceHash:=THashSHA2.GetHashStringFromFile(TPath.Combine(Fixture,'Main.dfm'));
 Analyzer:=TDPHAnalyzer.Create;Semantic:=TDPHSemanticAnalyzer.Create;
 try Scan:=Analyzer.Scan(TPath.Combine(Fixture,'Connections.dpr'),'Debug','Win32',[],[],False);
 try Graph:=Semantic.Analyze(Scan);
 try
 Database:=TPath.Combine(Work,'connections.dphdb');Store:=TDPHKnowledgeStore.Create(Database,Fixture,TPath.Combine(Root,'migrations'));
 try Store.InitializeProject('Controlled database connection inventory','Delphi');Config:=Store.AddConfiguration('Win32','37.0','[]','[]','Debug');Store.SelectConfiguration(Config);
 Generation:=TDPHSemanticPersistence.Stage(Scan,Graph,Store,Config);
 Document:=TDPHWorkspaceView.Capture(Scan,Graph,Generation,'Connections.dpr','Debug','Win32',[],[]);
 Store.SaveWorkspaceView(Generation,Document.ToJSON);TDPHSemanticPersistence.Publish(Scan,Graph,Store,Generation);
 View:=TDPHWorkspaceView.Create(Document);Reopened:=TDPHWorkspaceView.Create(TJSONObject.ParseJSONValue(Store.LoadWorkspaceView) as TJSONObject);
 Check(Store.IntegrityCheck='ok','Fixture SQLite integrity valid');
 finally Store.Free;end;
 finally Graph.Free;end;finally Scan.Free;end;finally Semantic.Free;Analyzer.Free;end;
 try
 TFile.WriteAllText(TPath.Combine(Work,'capture.json'),View.Document.ToJSON,TEncoding.UTF8);
 Report:=TDPHDatabaseConnections.Inspect(View);
 try
 TFile.WriteAllText(TPath.Combine(Work,'transaction-inventory.json'),Report.Format,TEncoding.UTF8);
 Check(Report.GetValue<Integer>('transaction_operation_count')>=25,'Transaction requests captured from actual source');
 for Text in ['Work','Cleanup','Branches','Missing','Cross','Retain','Derived'] do begin
  Row:=TxRow(Text,'StartTransaction');Check(Row<>nil,'Begin boundary retained for '+Text);
  Check(Row.GetValue<string>('source_hash')=THashSHA2.GetHashStringFromFile(TPath.Combine(Fixture,'TxTrace.pas')),'Transaction source SHA256 '+Text);
  Check(Row.GetValue<Integer>('flow_node_count')>0,'Transaction mapped to captured CFG '+Text);
  Check(not Row.GetValue<Boolean>('flow_truncated'),'Transaction paths not truncated '+Text);
 end;
 Check(HasPath(TxRow('Work','StartTransaction'),' / Commit /','normal'),'Begin reaches commit through protected normal path');
 Check(HasPath(TxRow('Work','StartTransaction'),' / Rollback /','exception'),'Begin reaches rollback through protected exception path');
 Check(HasPath(TxRow('Work','Commit'),' / Rollback /','exception'),'Commit may raise into rollback handler');
 Check(HasPath(TxRow('Work','Rollback'),'exception_exit','exception'),'Rollback and rethrow preserve exception exit');
 Check(HasPath(TxRow('Cleanup','StartTransaction'),' / Rollback /','normal'),'Normal path enters cleanup rollback');
 Check(HasPath(TxRow('Cleanup','StartTransaction'),' / Rollback /','exception'),'Error path enters cleanup rollback');
 Check(TxRow('Cleanup','Rollback').GetValue<Integer>('flow_node_count')>1,'Finalizer pending transfers remain separate CFG copies');
 Check(HasPath(TxRow('Branches','StartTransaction'),' / Commit /','conditional'),'Conditional commit path retained');
 Check(HasPath(TxRow('Branches','StartTransaction'),' / Rollback /','conditional'),'Conditional rollback alternative retained');
 Check(HasPath(TxRow('Missing','StartTransaction'),'normal_exit without another explicit boundary','normal'),'Missing local completion remains visible');
 Check(HasPath(TxRow('Cross','StartTransaction'),' / Rollback /','normal'),'Different receiver commit is not an ending for this transaction');
 Check(not HasPath(TxRow('Cross','StartTransaction'),' / Commit /','normal'),'Receiver boundaries never paired across connections');
 Check(TxRow('Retain','CommitRetaining').GetValue<string>('operation_kind')='commit retaining request','Commit retaining distinguished');
 Check(TxRow('Retain','RollbackRetaining').GetValue<string>('operation_kind')='rollback retaining request','Rollback retaining distinguished');
 Check(TxRow('Retain','RollbackSavepoint').GetValue<string>('operation_kind')='rollback savepoint request','Savepoint rollback distinguished');
 Check(TxRow('ADOWork','BeginTrans')<>nil,'ADO return-valued BeginTrans without parentheses captured');
 Check(TxRow('ADOWork','CommitTrans')<>nil,'ADO CommitTrans recognized');Check(TxRow('ADOWork','RollbackTrans')<>nil,'ADO RollbackTrans recognized');
 Check(TxRow('SQLWork','BeginTransaction')<>nil,'dbExpress BeginTransaction recognized');
 Check(TxRow('SQLWork','CommitFreeAndNil')<>nil,'dbExpress handle commit recognized');
 Check(TxRow('SQLWork','RollbackIncompleteFreeAndNil')<>nil,'dbExpress incomplete rollback recognized');
 Check(TxRow('BDEWork','StartTransaction')<>nil,'BDE start recognized');
 Check(TxRow('BDEWork','Commit')<>nil,'BDE commit recognized');
 Check(TxRow('BDEWork','Rollback')<>nil,'BDE rollback recognized');
 Check(TxRow('Ambiguous','BeginTrans').GetValue<Boolean>('flow_ambiguous'),'Calls sharing an expression remain unordered');
 Check(TxRow('Ambiguous','BeginTrans').GetValue<TJSONArray>('transaction_paths').Count=0,'Unordered expression cannot invent transaction sequence');
 Check(TxRow('Derived','StartTransaction').GetValue<TJSONArray>('links').Items[0].GetValue<string>('target_id')<>'','Captured connection descendant retains exact receiver');
 for Value in Report.GetValue<TJSONArray>('rows') do if Value.GetValue<string>('role')='transaction operation' then begin
  Check(Value.GetValue<string>('source')<>'TxShadow.pas','Ordinary and locally shadowed transaction-like methods excluded');
  Check(Value.GetValue<string>('effect').Contains('unobserved') or Value.GetValue<string>('effect').Contains('raise') or Value.GetValue<string>('effect').Contains('review'),'Transaction outcome remains qualified');
 end;
 Check(TDPHDatabaseConnections.Describe(TxRow('Work','StartTransaction')).StartsWith('TRANSACTION PATHS'),'Path explanation appears before generic configuration');
 Check(not Report.ToJSON.Contains('SENSITIVE_SAVEPOINT_CANARY'),'Savepoint argument never copied to inventory');
 Document:=View.Document.Clone as TJSONObject;
 Document.RemovePair('semantics').Free;
 Document.AddPair('semantics',View.Document.GetValue('semantics').Clone as TJSONValue);
 Document.GetValue<TJSONObject>('semantics').RemovePair('flow_nodes').Free;
 Document.GetValue<TJSONObject>('semantics').AddPair('flow_nodes',TJSONArray.Create);
 Document.GetValue<TJSONObject>('semantics').RemovePair('flow_edges').Free;
 Document.GetValue<TJSONObject>('semantics').AddPair('flow_edges',TJSONArray.Create);
 Reopened.Free;Reopened:=TDPHWorkspaceView.Create(Document);
 Row:=TDPHDatabaseConnections.Inspect(Reopened);
 try for Value in Row.GetValue<TJSONArray>('rows') do if Value.GetValue<string>('role')='transaction operation' then
   Check(Value.GetValue<Integer>('flow_node_count')=0,'Absent CFG never invents transaction paths');
 finally Row.Free;end;
 Reopened.Free;Reopened:=TDPHWorkspaceView.Create(View.Document.Clone as TJSONObject);
 Document:=View.Document.Clone as TJSONObject;
 for I:=1 to 10001 do begin
   Row:=Document.GetValue<TJSONArray>('semantics.flow_nodes').Items[0].Clone as TJSONObject;
   Row.RemovePair('id').Free;Row.AddPair('id',TJSONNumber.Create(100000+I));
   Row.RemovePair('routine').Free;Row.AddPair('routine',TxRow('Work','StartTransaction').GetValue<string>('routine_key'));
   Document.GetValue<TJSONArray>('semantics.flow_nodes').AddElement(Row);
 end;
 Reopened.Free;Reopened:=TDPHWorkspaceView.Create(Document);
 Row:=TDPHDatabaseConnections.Inspect(Reopened);
 try for Value in Row.GetValue<TJSONArray>('rows') do if Value.GetValue<string>('path')=TxRow('Work','StartTransaction').GetValue<string>('path') then begin
   Check(Value.GetValue<Boolean>('flow_truncated'),'Oversized routine CFG explicitly reports truncation');
   Check(Value.GetValue<TJSONArray>('transaction_paths').Count=0,'Oversized CFG cannot invent completion paths');
 end;finally Row.Free;end;
 Reopened.Free;Reopened:=TDPHWorkspaceView.Create(View.Document.Clone as TJSONObject);
 Check(Report.GetValue<Integer>('operation_count')>=25,'Operation inventory includes dataset API, literal SQL and dynamic SQL');
 for Text in ['Open','Refresh','First','Next','Locate','Append','Insert','AppendRecord','InsertRecord','Edit','Post','Delete','Cancel','ApplyUpdates','CancelUpdates','ExecSQL'] do begin
  Row:=Find(Text);Check((Row<>nil) and (Row.GetValue<string>('role')='database operation'),'Captured dataset request '+Text);
  Check(Row.GetValue<string>('source_hash')=THashSHA2.GetHashStringFromFile(TPath.Combine(Fixture,'Main.pas')),'Operation source SHA256 '+Text);
  Check(Row.GetValue<Integer>('range.line')>0,'Operation source line '+Text);
  Check(Reference(Text,'DataSet').GetValue<string>('target_id')=Find('Query').GetValue<string>('id'),'Operation follows exact serialized dataset '+Text);
 end;
 I:=0;for Value in Report.GetValue<TJSONArray>('rows') do if Value.GetValue<string>('role')='database operation' then begin
  Row:=Value as TJSONObject;Check(Row.GetValue<string>('source')<>'Shadow.pas','Local class shadowing framework name is excluded');
  if Row.GetValue<string>('name')='Delete' then begin Inc(I);
   if Row.GetValue<TJSONArray>('links').Items[0].GetValue<string>('reference')='Records' then
    Check(Row.GetValue<TJSONArray>('links').Items[0].GetValue<string>('target_id')=Find('Records').GetValue<string>('id'),'Custom dataset descendant follows exact declaration');
  end;
 end;
 Check(I=2,'Delete recognizes framework dataset and custom descendant only');
 I:=0;for Value in Report.GetValue<TJSONArray>('rows') do if Value.GetValue<string>('name')='configured SQL' then begin
  Inc(I);Text:=Value.GetValue<string>('operation_kind');
  case I of 1:Check(Text='read','Joined SELECT remains a lexical read candidate');2:Check(Text='insert','INSERT SQL family retained');3:Check(Text='update','UPDATE SQL family retained');4:Check(Text='delete','DELETE SQL family retained');5:Check(Text='unknown','Mixed SQL batch never collapsed to first statement');end;
 end;
 Check(Find('Post').GetValue<string>('effect').Contains('does not prove transaction commit'),'Post never claims commit');
 Check(Find('Append').GetValue<string>('operation_kind')='insert preparation','Append distinguishes preparation from inserted row');
 Check(Find('Edit').GetValue<string>('operation_kind')='update preparation','Edit distinguishes preparation from updated row');
 Check(Find('Cancel').GetValue<string>('effect').Contains('does not establish rollback'),'Cancel never claims transaction rollback');
 Check(Find('ApplyUpdates').GetValue<string>('operation_kind')='mixed pending writes','Cached writes remain mixed');
 I:=0;for Value in Report.GetValue<TJSONArray>('rows') do if Value.GetValue<string>('role')='database operation' then begin
  Text:=Value.GetValue<string>('path');Check(not Text.Contains('OrdinaryObject'),'Ordinary Delete is not a database operation');
  if Value.GetValue<string>('name')='configured SQL' then begin
   Inc(I);Check(Value.GetValue<string>('effect').Contains('does not execute'),'SQL configuration never claims execution');
  end;
 end;
 Check(I=5,'All five literal SQL configurations retained including joins and mixed batch');
 Check(Find('dynamic SQL').GetValue<string>('operation_kind')='unknown','Dynamic SQL does not invent CRUD kind');
 Check(TDPHKeyboardInspector.ReadSource(View,TPath.Combine(Fixture,'Connections.dpr'),Find('Post'),Find('Post').GetValue<TJSONObject>('range')).Contains('Query.Post'),'Hash checked source navigation reads operation source');
 Check(Reference('TouchLink','Control').GetValue<string>('target_id')=Find('TouchEdit').GetValue<string>('id'),'FMX binding links actual control target');
 Check(Find('TouchEdit').GetValue<TJSONArray>('used_by').Count=1,'FMX edit has reverse binding link');
 Check(Find('Amount').GetValue<string>('role')='persistent field','Persistent field is explicitly classified');
 Check(Find('AmountEdit').GetValue<string>('role')='bound control','Data-aware control is classified');
 Check(Reference('Amount','DataSet').GetValue<string>('target_id')=Find('Query').GetValue<string>('id'),'Field parent resolves exact owning dataset');
 Check(Reference('AmountEdit','DataSource').GetValue<string>('target_id')=Find('Source').GetValue<string>('id'),'Control resolves data source');
 Check(Reference('AmountEdit','DataField').GetValue<string>('target_id')=Find('Amount').GetValue<string>('id'),'Control field resolves through dataset chain');
 Check(Reference('AmountEdit','DataField').GetValue<Integer>('line')>0,'Field binding retains property line');
 Check(Reference('AmountEdit','DataField').GetValue<Integer>('end')>Reference('AmountEdit','DataField').GetValue<Integer>('start'),'Field binding retains byte range');
 Check(Find('Amount').GetValue<TJSONArray>('used_by').ToJSON.Contains(Find('AmountEdit').GetValue<string>('id')),'Persistent field retains exact bound control among all dependents');
 Check(Reference('CodeEdit','DataField').GetValue<string>('resolution').Contains('ambiguous'),'Duplicate field names remain ambiguous');
 Check(not Reference('CodeEdit','DataField').ToJSON.Contains('target_id'),'Duplicate fields never select arbitrary target');
 Check(not Reference('DynamicEdit','DataField').ToJSON.Contains('target_id'),'Runtime field is not invented');
 Check(not Reference('BrokenEdit','DataField').ToJSON.Contains('target_id'),'Missing source prevents field link');
 Check(not Reference('NilEdit','DataField').ToJSON.Contains('target_id'),'Nil source prevents field link');
 Check(Reference('Lookup','LookupDataSet').GetValue<string>('target_id')=Find('Query').GetValue<string>('id'),'Lookup dataset reference navigable');
 Check(not Reference('Lookup','DataSet').ToJSON.Contains('target_id'),'Field with non-dataset parent remains unowned');
 Check(Reference('TouchLink','FieldName').GetValue<string>('target_id')=Find('TouchID').GetValue<string>('id'),'FMX BindSource chain resolves captured field');
 Check(Reference('BinaryEdit','DataField').GetValue<string>('target_id')=Find('BinaryID').GetValue<string>('id'),'Binary DFM field chain resolves');
 Check(TDPHDatabaseConnections.Describe(Find('Amount')).Contains('Required = True'),'Field metadata shown');
 Check(TDPHDatabaseConnections.Describe(Find('AmountEdit')).StartsWith('DATASET AND SCREEN BINDINGS'),'Binding explanation precedes engine guidance');
 Check(Find('MainConnection')<>nil,'Text DFM connection captured');
 Check(Find('MainConnection').GetValue<string>('role')='connection','Known connection class classified');
 Check(Find('Query').GetValue<string>('role')='dataset','Dataset classified');
 Check(Find('Source').GetValue<string>('role')='data source','Data source classified');
 Check(Find('Tx').GetValue<string>('role')='transaction','Transaction classified');
 Check(Find('Session').GetValue<string>('role')='session','Session classified');
 Check(Find('Custom').GetValue<string>('role')='database candidate','Custom class property signal remains candidate');
 Check(Find('Main.TMainModule.Unserialized')<>nil,'Pascal-only declaration retained');
 I:=0;for Value in Report.GetValue<TJSONArray>('rows') do if Value.GetValue<string>('name')='Main.TMainModule.MainConnection' then Inc(I);
 Check(I=0,'Confirmed component-field binding avoids duplicate declaration row');
 Check(Reference('Query','Connection').GetValue<string>('target_id')=Find('MainConnection').GetValue<string>('id'),'Dataset connection links uniquely');
 Check(Reference('Source','DataSet').GetValue<string>('target_id')=Find('Query').GetValue<string>('id'),'Data source links to dataset');
 Check(Reference('RemoteQuery','Connection').GetValue<string>('target_id')=Find('RemoteConnection').GetValue<string>('id'),'Qualified cross-module reference links');
 Check(Reference('Broken','Connection').GetValue<string>('resolution').Contains('unresolved'),'Missing target explicitly unresolved');
 Check(not Reference('Broken','Connection').ToJSON.Contains('target_id'),'Missing target not fabricated');
 Check(not Reference('UnqualifiedRemote','Connection').ToJSON.Contains('target_id'),'Unqualified external target is not guessed');
 Check(Find('Ordinary')=nil,'Unrelated visual component excluded');
 Check(Reference('NilQuery','Connection').GetValue<string>('resolution')='explicit nil reference','Nil stays explicit');
 Check(not Reference('WrongRole','Connection').ToJSON.Contains('target_id'),'Wrong-role target not linked');
 Check(Reference('Expression','Connection').GetValue<string>('reference')='[unsupported reference expression]','Unsupported expression masked');
 Check(Reference('IBQuery','Database').GetValue<string>('target_id')=Find('IB').GetValue<string>('id'),'IB database reference links');
 Check(Reference('IBQuery','Transaction').GetValue<string>('target_id')=Find('Tx').GetValue<string>('id'),'Transaction reference links');
 Check(Reference('Tx','DefaultDatabase').GetValue<string>('target_id')=Find('IB').GetValue<string>('id'),'Transaction default database links');
 Check(Reference('LegacyQuery','DatabaseName').GetValue<string>('target_id')=Find('Legacy').GetValue<string>('id'),'BDE logical database alias links');
 Check(Reference('Legacy','SessionName').GetValue<string>('target_id')=Find('Session').GetValue<string>('id'),'Session alias links');
 Check(Reference('NestedQuery','Connection').GetValue<string>('target_id')=Find('NestedConnection').GetValue<string>('id'),'Parent-local nested path links');
 Check(Reference('SelfQuery','Connection').GetValue<string>('target_id')=Find('MainConnection').GetValue<string>('id'),'Self-qualified reference links');
 Check(Reference('Ambiguous','Connection').GetValue<string>('resolution').Contains('ambiguous'),'Duplicate paths remain ambiguous');
 Check(not Reference('Ambiguous','Connection').ToJSON.Contains('target_id'),'Ambiguous target not followed');
 Check(Find('PrimaryDef').GetValue<string>('role')='connection definition','Named definition inventoried');
 Check(Find('PrimaryDef').GetValue<TJSONArray>('used_by').Count=2,'Shared definition has both referencing connections');
 Check(Find('PrimaryDef').GetValue<string>('availability').Contains('unavailable'),'External definition contents not invented');
 Check(Find('MainConnection').GetValue<TJSONArray>('used_by').Count>270,'Reverse dataset dependencies retained');
 Check(Find('BinaryConnection')<>nil,'Binary DFM connection captured');
 Check(Reference('BinaryQuery','Connection').TryGetValue<string>('target_id',Text),'Binary reference resolved');
 Check(Reference('TouchQuery','SQLConnection').GetValue<string>('target_id')=Find('TouchConnection').GetValue<string>('id'),'FMX connection reference resolved');
 Check(Find('InheritedQuery').GetValue<string>('declaration')='inherited','Inherited declaration preserved');
 Check(Find('InheritedQuery').GetValue<TJSONArray>('configuration').Count=0,'Missing configuration not invented');
 Check(not Report.ToJSON.Contains('SENSITIVE_'),'All sensitive configuration canaries absent from projection');
 Check(TDPHDatabaseConnections.Describe(Find('MainConnection')).Contains('DriverID = FB'),'Validated driver metadata shown');
 Check(TDPHDatabaseConnections.Describe(Find('MainConnection')).Contains('Port = 3050'),'Valid port shown');
 Check(TDPHDatabaseConnections.Describe(Find('BadConfig')).Contains('[REDACTED configuration value]'),'Invalid driver and port masked');
 Check(TDPHDatabaseConnections.Describe(Find('MainConnection')).Contains('not evidence of a successful connection'),'Connected flag qualified');
 Check(Find('MainConnection').GetValue<string>('source_hash')=SourceHash,'Exact source hash retained');
 Row:=TDPHDatabaseConnections.Inspect(Reopened);try Check(Row.ToJSON=Report.ToJSON,'Reopened captured database gives identical inventory');finally Row.Free;end;
 Catalog:=TDPHWorkspaceCatalog.DefaultPath;CatalogHash:='';if TFile.Exists(Catalog) then CatalogHash:=THashSHA2.GetHashStringFromFile(Catalog);
 Form:=TDPHMainForm.Create(nil);
 try Form.PollTimer.Enabled:=False;Form.ChangeTimer.Enabled:=False;Form.LoadView(View.Document.Clone as TJSONObject);
 Check(Form.WorkspacePageCombo.Items.IndexOf('Database connections')>=0,'Inventory page discoverable');
 Check(Form.DatabaseInventoryList.Count=250,'Native page paginates at 250');Check(Form.DatabaseInventoryNext.Enabled,'Next enabled for remaining rows');
 Form.DatabaseInventoryFilterChange(Form.DatabaseInventoryNext);Check(Form.DatabaseInventoryList.Count<250,'Next shows bounded remaining rows');
 Form.DatabaseInventoryKind.ItemIndex:=2;Form.DatabaseInventoryFilter.Text:='RemoteQuery';Form.DatabaseInventoryFilterChange(nil);Check(Form.DatabaseInventoryList.Count=1,'Native text and kind filters find dataset');
 Form.DatabaseInventoryList.ItemIndex:=0;Form.DatabaseInventorySelectionChange(nil);Check(Form.DatabaseInventoryFollow.Enabled,'Unique reference enables follow');
 Form.DatabaseInventoryFollowClick(nil);Check(Form.DatabaseInventoryMemo.Text.Contains('CONNECTION RemoteDM.RemoteConnection'),'Follow navigates exact target');
 Check(Form.DatabaseInventoryLinks.Items.Count>0,'Reverse references navigable');
 Form.DatabaseInventoryKind.ItemIndex:=6;Form.DatabaseInventoryFilterChange(nil);Check(Form.DatabaseInventoryList.Count=1,'Named definition kind filter');
 Check(Form.DatabaseInventoryMemo.Text.Contains('External definition contents'),'Native details explain unknown definition contents');
 Form.DatabaseInventoryKind.ItemIndex:=1;Form.DatabaseInventoryFilter.Text:='MainConnection';Form.DatabaseInventoryFilterChange(nil);
 Check(not Form.DatabaseInventoryMemo.Text.Contains('SENSITIVE_'),'Native details omit sensitive values');
 Form.DatabaseInventoryFilter.Text:='NO_MATCH_FIXTURE';Form.DatabaseInventoryFilterChange(nil);
 Check(Form.DatabaseInventoryList.Count=0,'Empty filter has no invented rows');
 Check(not Form.DatabaseInventoryFollow.Enabled,'Empty filter disables reference navigation');
 Check(Form.DatabaseInventoryMemo.Text.Contains('Runtime-only factories'),'Empty inventory explains coverage limits');
 Form.DatabaseInventoryFilter.Text:='MainConnection';Form.DatabaseInventoryFilterChange(nil);
 Form.DatabaseInventoryKind.ItemIndex:=Form.DatabaseInventoryKind.Items.IndexOf('bound control');Form.DatabaseInventoryFilter.Text:='AmountEdit';Form.DatabaseInventoryFilterChange(nil);
 Check(Form.DatabaseInventoryList.Count=1,'Native bound control filter finds control');
 Check(Form.DatabaseInventoryMemo.Text.Contains('DataField -> amount'),'Native details show captured field binding');
 for I:=0 to Form.DatabaseInventoryLinks.Items.Count-1 do if Form.DatabaseInventoryLinks.Items[I].StartsWith('Target via DataField:') then Form.DatabaseInventoryLinks.ItemIndex:=I;
 Form.DatabaseInventoryFollowClick(nil);Check(Form.DatabaseInventoryMemo.Text.Contains('PERSISTENT FIELD MainModule.Query.Amount'),'Native follow opens exact persistent field');
 Check(Form.DatabaseInventoryLinks.Items.Count>=2,'Field has dataset and reverse control links');
 Form.DatabaseInventoryKind.ItemIndex:=Form.DatabaseInventoryKind.Items.IndexOf('persistent field');Form.DatabaseInventoryFilter.Text:='AMOUNT';Form.DatabaseInventoryFilterChange(nil);
 Check(Form.DatabaseInventoryList.Count=1,'Field name search finds persistent field');
 Form.DatabaseInventoryKind.ItemIndex:=Form.DatabaseInventoryKind.Items.IndexOf('database operation');Form.DatabaseInventoryFilter.Text:='Post';Form.DatabaseInventoryFilterChange(nil);
 Check(Form.DatabaseInventoryList.Count=2,'Native filter finds both dataset Post sites');
 Check(Form.DatabaseInventoryMemo.Text.Contains('DATABASE OPERATION'),'Native operation effect appears first');
 Check(Form.DatabaseInventorySource.Enabled,'Native source command is available');
 Form.DatabaseInventorySourceClick(nil);Check(Form.DatabaseInventoryMemo.Text.Contains('Source is detached'),'Detached capture refuses source access');
 Form.DatabaseInventoryFilter.Text:='Delete';Form.DatabaseInventoryFilterChange(nil);
 Form.DatabaseInventoryKind.ItemIndex:=Form.DatabaseInventoryKind.Items.IndexOf('transaction operation');Form.DatabaseInventoryFilter.Text:='.Work / StartTransaction';Form.DatabaseInventoryFilterChange(nil);
 Check(Form.DatabaseInventoryList.Count=3,'Native transaction search includes three linked routine boundaries');
 for I:=0 to Form.DatabaseInventoryList.Count-1 do if Form.DatabaseInventoryList.Items[I].Contains(' | TxTrace.TTx.Work / StartTransaction /') then Form.DatabaseInventoryList.ItemIndex:=I;
 Form.DatabaseInventorySelectionChange(nil);
 Check(Form.DatabaseInventoryMemo.Text.StartsWith('TRANSACTION PATHS'),'Native transaction details explain paths first');
 Check(Form.DatabaseInventoryMemo.Text.Contains('possible exception path'),'Native details show possible rollback exception path');
 Check(Form.DatabaseInventorySource.Enabled,'Transaction source navigation available');
 for I:=0 to Form.DatabaseInventoryLinks.Items.Count-1 do if Form.DatabaseInventoryLinks.Items[I].Contains('possible normal path') and Form.DatabaseInventoryLinks.Items[I].Contains(' / Commit /') then Form.DatabaseInventoryLinks.ItemIndex:=I;
 Form.DatabaseInventoryFollowClick(nil);Check(Form.DatabaseInventoryMemo.Text.Contains('COMMIT REQUEST'),'Native follow opens the next transaction boundary');
 Form.DatabaseInventoryFilter.Text:='.Work / StartTransaction';Form.DatabaseInventoryFilterChange(nil);
 Form.DatabaseInventoryKind.ItemIndex:=Form.DatabaseInventoryKind.Items.IndexOf('transaction operation');Form.DatabaseInventoryFilterChange(nil);
 for I:=0 to Form.DatabaseInventoryList.Count-1 do if Form.DatabaseInventoryList.Items[I].Contains(' | TxTrace.TTx.Work / StartTransaction /') then Form.DatabaseInventoryList.ItemIndex:=I;
 Form.DatabaseInventorySelectionChange(nil);
 Form.WorkspaceTabs.ActiveTab:=Form.DatabaseInventoryTab;Form.Show;Render('phase1-database-transactions-workspace.png');
 Form.WindowState:=TWindowState.wsNormal;Form.Width:=960;Form.Height:=600;Render('phase1-database-transactions-compact.png');
 Check(Form.DatabaseInventoryToolbar.ShowScrollBars,'Compact commands scroll horizontally');Check(Form.DatabaseInventoryMemo.ShowScrollBars,'Evidence memo scrolls');
 Check(Form.DatabaseInventoryMemo.Width<400,'Compact evidence stays in workspace pane');
 Check(Form.DatabaseInventoryMemo.Height>=50,'Compact evidence retains usable visible height');
 Form.LoadView(View.Document.Clone as TJSONObject);Check(not Form.DatabaseInventoryMemo.Text.Contains('SENSITIVE_'),'Capture replacement retains redaction');Form.Hide;
 finally Form.Free;end;
 Check((not TFile.Exists(Catalog) and (CatalogHash='')) or (TFile.Exists(Catalog) and (THashSHA2.GetHashStringFromFile(Catalog)=CatalogHash)),'Owner catalog unchanged');
 Check(THashSHA2.GetHashStringFromFile(TPath.Combine(Fixture,'Main.dfm'))=SourceHash,'Analyzed source unchanged');
 Log:=TJSONObject.Create.AddPair('result','PASS').AddPair('checks',TJSONNumber.Create(Checks)).AddPair('qualification','Actual parser, persisted and reopened captures, redacted configuration and native FMX controls. No target database is opened; fixtures contain only controlled canaries.');
 try TFile.WriteAllText(TPath.Combine(Root,'docs\validation\reports\phase1-database-transactions-validation.json'),Log.Format,TEncoding.UTF8);finally Log.Free;end;
 finally Report.Free;end;
 finally Reopened.Free;View.Free;end;
 Writeln('Database transactions validation passed: ',Checks,' checks.');
 except on E:Exception do begin Writeln(E.ClassName,': ',E.Message);ExitCode:=1;end;end;
end.
