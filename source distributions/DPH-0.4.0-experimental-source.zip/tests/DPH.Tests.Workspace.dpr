program DPH.Tests.Workspace;
{$APPTYPE CONSOLE}
uses System.SysUtils, System.Classes, System.IOUtils, System.JSON, System.Diagnostics, System.UITypes,
  System.Hash, System.Types, FMX.Forms, FMX.Graphics, Winapi.ActiveX,
  DPH.UI.Main in '..\DPH.UI.Main.pas',
  DPH.Workspace.Model in '..\DPH.Workspace.Model.pas',
  DPH.Workspace.Worker in '..\DPH.Workspace.Worker.pas',
  DPH.Workspace.Screen in '..\DPH.Workspace.Screen.pas',
  DPH.Workspace.Graphs in '..\DPH.Workspace.Graphs.pas',
  DPH.Publish.Model in '..\DPH.Publish.Model.pas',
  DPH.Publish.Translation in '..\DPH.Publish.Translation.pas',
  DPH.Analysis.Explanations in '..\DPH.Analysis.Explanations.pas',
  DPH.Storage.Database in '..\DPH.Storage.Database.pas',
  DPH.Project.Analysis in '..\DPH.Project.Analysis.pas',
  DPH.Analysis.Model in '..\DPH.Analysis.Model.pas',
  DPH.Analysis.Symbols in '..\DPH.Analysis.Symbols.pas';
var Root,Work,Fixture,Path,Key,ComponentKey,Kind,FilterText,QuestionID: string; ID: TGUID; Checks: Integer;
    Worker: TDPHWorkspaceWorker; Request: TDPHWorkspaceRequest; Response: TDPHWorkspaceResponse;
    View: TDPHWorkspaceView; Rows,RichLinks,Questions: TJSONArray; J,Screen,BaseGraph,GroupedGraph,Row: TJSONObject; V: TJSONValue;
    Form: TDPHMainForm; Bitmap: TBitmap; Watch: TStopwatch; Generation,TargetNote,LinkNote,TargetRevision,LinkRevision,AnswerID,AnswerRevision: Int64; EscapeKey: Word; EscapeChar: Char; SavedScreenWidth: Single;
    Facts: TDPHDocumentModel; Explanation: TDPHExplanationModel; HTML: string;
    Before,After,RootKey,ValidationReportText: string; Failed,CachedShownBeforeVerification,FoundChild: Boolean; RootCount,ExpandedCount,Members,Relationships: Integer;
    NativeStore: TDPHKnowledgeStore; TranslationCache: TDPHTranslationCache; TranslationProvider: IDPHTranslationProvider;
    TranslationNote,TranslationRevision: Int64; TranslationRequest: TDPHWorkspaceRequest;
procedure Check(OK: Boolean; const MessageText: string);
begin if not OK then raise Exception.Create('FAIL '+MessageText); Inc(Checks); Writeln('PASS ',Checks,': ',MessageText); end;
function WaitResponse: TDPHWorkspaceResponse;
var Start: TStopwatch;
begin
  Start:=TStopwatch.StartNew;
  repeat
    Application.ProcessMessages;
    if Worker.Poll(Result) then begin
      if Result.Busy and (Result.Document<>nil) then CachedShownBeforeVerification:=True;
      if not Result.Busy then Exit; Result.Free;
    end;
    if Start.ElapsedMilliseconds>60000 then raise Exception.Create('Worker timed out');
    TThread.Sleep(10);
  until False;
end;
begin
  CoInitialize(nil); Application.Initialize;
  try
    try
      Root:=TPath.GetFullPath(ParamStr(1)); CreateGUID(ID); Work:=TPath.Combine(Root,'bin\wp4-tests-'+GUIDToString(ID));
      Fixture:=TPath.Combine(Work,'fixture'); TDirectory.CreateDirectory(Fixture);
      for Path in TDirectory.GetFiles(TPath.Combine(Root,'tests\fixtures\semantics')) do TFile.Copy(Path,TPath.Combine(Fixture,ExtractFileName(Path)));
      Before:=THashSHA2.GetHashStringFromFile(TPath.Combine(Fixture,'Main.pas'));
      Worker:=TDPHWorkspaceWorker.Create(Root);
      try
        Request.Command:='incremental'; Request.Entry:=TPath.Combine(Fixture,'Semantic.dproj'); Request.Database:=TPath.Combine(Work,'workspace.dphdb');
        Request.Configuration:='Debug'; Request.Platform:='Win32'; Request.Defines:=[]; Request.ExternalRoots:=[];
        Worker.Submit(Request); Response:=WaitResponse;
        try
          Check(not Response.Failed,Response.MessageText); Check(Response.Document<>nil,'Background scan returns a captured workspace');
          View:=TDPHWorkspaceView.Create(Response.Document); Response.Document:=nil;
        finally Response.Free; end;
        try
          Generation:=View.Document.GetValue<Int64>('generation_id');
          Check(Generation>0,'Workspace includes its immutable generation');
          Rows:=View.Search('Click','routine',''); try Check(Rows.Count=1,'Project-wide search selects method identity'); Key:=(Rows.Items[0] as TJSONObject).GetValue<string>('key'); finally Rows.Free; end;
          Rows:=View.Search('btnConvert','component',''); try Check(Rows.Count=1,'Form component is searchable'); ComponentKey:=(Rows.Items[0] as TJSONObject).GetValue<string>('key'); finally Rows.Free; end;
          Rows:=View.Properties(ComponentKey); try Check(Rows.Count>0,'Inspector retains serialized properties'); finally Rows.Free; end;
          Rows:=View.Details(ComponentKey); try Check((Rows.Count>0) and (Rows.Items[0].GetValue<string>('detail_kind')='property') and
            (Rows.Items[0].GetValue<string>('rule')='serialized_override_not_framework_default'),'Component details distinguish serialized values from unknown defaults'); finally Rows.Free; end;
          Rows:=View.Details(Key); try Check((Rows.Count>0) and (Rows.Items[0].GetValue<string>('detail_kind')='statement') and
            (Rows.Items[0].GetValue<string>('source_hash')<>''),'Routine details retain statement text and immutable source evidence'); finally Rows.Free; end;
          Rows:=View.Neighbors(Key,'reverse'); try Check(Rows.Count>0,'Reverse references retain event evidence'); finally Rows.Free; end;
          Rows:=View.Search('Main','unit',''); try RootKey:=(Rows.Items[0] as TJSONObject).GetValue<string>('key'); finally Rows.Free; end;
          Rows:=View.Hierarchy([]); try
            RootCount:=Rows.Count; FoundChild:=False;
            for V in Rows do if (V as TJSONObject).GetValue<Integer>('depth')<>0 then FoundChild:=True;
            Check((RootCount>0) and not FoundChild,'Collapsed hierarchy shows only ownership roots');
          finally Rows.Free; end;
          Rows:=View.Hierarchy([RootKey]); try
            ExpandedCount:=Rows.Count; FoundChild:=False;
            for V in Rows do if (V as TJSONObject).GetValue<Integer>('depth')=1 then FoundChild:=True;
            Check((ExpandedCount>RootCount) and FoundChild,'Expanding a module reveals its immediate owned objects');
          finally Rows.Free; end;
          Rows:=View.Hierarchy([]); try Check(Rows.Count=RootCount,'Collapsing a branch restores root rows without changing the source model'); finally Rows.Free; end;
          Rows:=View.Hierarchy([RootKey],1,2); try Check(Rows.Count=2,'Hierarchy pagination is applied after branch visibility'); finally Rows.Free; end;
          BaseGraph:=View.Graph('Execution',Key,1000);
          try for Kind in ['Types','Units'] do begin
            GroupedGraph:=TDPHGraphProjection.Group(View,BaseGraph,Kind);
            try
              Members:=0; Relationships:=0;
              for V in GroupedGraph.GetValue<TJSONArray>('nodes') do begin Inc(Members,V.GetValue<Integer>('member_count')); Inc(Relationships,V.GetValue<Integer>('internal_relationships')); end;
              for V in GroupedGraph.GetValue<TJSONArray>('edges') do Inc(Relationships,V.GetValue<Integer>('relationship_count'));
              Check((Members=BaseGraph.GetValue<TJSONArray>('nodes').Count) and (GroupedGraph.GetValue<TJSONArray>('nodes').Count<Members),Kind+' grouping retains every captured member while collapsing nodes');
              Check(Relationships=BaseGraph.GetValue<TJSONArray>('edges').Count,Kind+' grouping retains internal and external relationship counts');
              Facts:=TDPHDocumentModel.Create(View,nil,[],[],True,not View.Document.GetValue<Boolean>('analysis_complete'),nil,True);
              try Explanation:=TDPHExplanationModel.Create(Facts.Document);
                try
                  HTML:=Explanation.GraphHTML(GroupedGraph);
                  Check(HTML.Contains('<svg') and HTML.Contains('#g_') and HTML.Contains('marker-end'),'Grouped graph HTML renders directed labeled nodes with member navigation');
                  TFile.WriteAllText(TPath.Combine(Work,'grouped-graph.html'),HTML,TEncoding.UTF8);
                  Row:=(GroupedGraph.GetValue<TJSONArray>('nodes').Items[0] as TJSONObject);
                  Row.RemovePair('label').Free; Row.AddPair('label','<script>alert(1)</script>');
                  HTML:=Explanation.GraphHTML(GroupedGraph);
                  Check(HTML.Contains('&lt;script&gt;') and not HTML.Contains('<script>'),'Graph labels escape analyzed source text as inert content');
                finally Explanation.Free; end;
              finally Facts.Free; end;
            finally GroupedGraph.Free; end;
          end; finally BaseGraph.Free; end;
          BaseGraph:=View.Graph('Execution',Key,1);
          try GroupedGraph:=TDPHGraphProjection.Group(View,BaseGraph,'Units');
            try Check(GroupedGraph.GetValue<Boolean>('truncated'),'Grouped graph preserves source-projection truncation'); finally GroupedGraph.Free; end;
          finally BaseGraph.Free; end;
          for Kind in ['Execution','Procedure CFG','Caller / callee','Form navigation','Data flow','Change impact'] do begin
            J:=View.Graph(Kind,Key,5); try Check(J.GetValue<TJSONArray>('nodes').Count<=5,Kind+' graph is bounded'); Check(not J.GetValue<Boolean>('runtime_trace'),Kind+' graph has static provenance'); finally J.Free; end;
          end;
          Screen:=TDPHScreenLayout.Reconstruct(View,'Main.fmx');
          try Check(Screen.GetValue<TJSONArray>('components').Count=2,'Design-time screen contains form and button');
            Check(Pos('not a runtime',Screen.GetValue<string>('provenance'))>0,'Screen reconstruction never claims runtime capture'); finally Screen.Free; end;
          Form:=TDPHMainForm.Create(nil);
          try
            Form.LoadView(View.Document.Clone as TJSONObject); Check(Form.ExplorerList.Items.Count>0,'FMX Explorer displays canonical cached objects');
            RootCount:=Form.ExplorerList.Items.Count; Form.ExplorerList.ItemIndex:=0; Form.ExplorerExpandClick(nil);
            Check(Form.ExplorerList.Items.Count>RootCount,'IDE-editable expand button opens the selected Explorer branch');
            Form.ExplorerExpandClick(nil); Check(Form.ExplorerList.Items.Count=RootCount,'Explorer branch collapse preserves other roots');
            Check((Form.ConfigurationCombo.Items.Count=View.Document.GetValue<TJSONArray>('configurations').Count) and
              (Form.PlatformCombo.Items.Count=View.Document.GetValue<TJSONArray>('platforms').Count),'FMX choices come from captured project options');
            Check(Form.CodePageEdit.Text='0','Captured code page is visible in the source settings');
            J:=View.Coverage;
            try
              Check((J.GetValue<TJSONArray>('metrics').Count=8) and
                (J.GetValue<TJSONArray>('metrics').Items[0].GetValue<Integer>('denominator')=View.Document.GetValue<TJSONArray>('syntax.files').Count),
                'Coverage metrics define inventory denominator explicitly');
              Check(J.GetValue<TJSONArray>('diagnostics').Count=View.Document.GetValue<TJSONArray>('syntax.diagnostics').Count+
                View.Document.GetValue<TJSONArray>('semantics.diagnostics').Count,'Coverage retains syntax and semantic diagnostic evidence');
            finally J.Free; end;
            Check(Form.CoverageMemo.Text.Contains('not proof') and Form.CoverageMemo.Text.Contains('denominator'),
              'Coverage page explains human-review limits separately from static measures');
            if Form.CoverageList.Count>0 then begin
              Form.CoverageList.ItemIndex:=0; Form.CoverageInspectClick(nil);
              Check((Form.WorkspaceTabs.ActiveTab=Form.DetailsTab) and Form.DetailsMemo.Text.StartsWith('diagnostic:'),
                'Coverage gap opens labeled source evidence in Details');
            end;
            Form.SearchEdit.Text:='Click'; Form.ExplorerList.ItemIndex:=0; Form.ExplorerClick(nil);
            Check(Pos('Main.TMain.Click',Form.InspectorMemo.Text)>0,'Explorer selection populates source-backed inspector');
            Check(Pos('detached',Form.SourceMemo.Text)>0,'Detached source view does not follow cached filesystem paths');
            Check(Form.DetailsList.Items.Count>0,'Selected routine populates IDE-editable statement/evidence rows');
            Form.DetailsList.ItemIndex:=0; Form.DetailsClick(nil);
            Check(Pos('SHA256:',Form.DetailsMemo.Text)>0,'Evidence pane labels certainty, rule and source hash');
            Form.WorkspaceTabs.ActiveTab:=Form.DetailsTab; Form.DetailsSourceClick(nil);
            Check((Form.WorkspaceTabs.ActiveTab=Form.DetailsTab) and (Pos('detached',Form.DetailsMemo.Text)>0),'Detached evidence command retains cached details without following filesystem paths');
            Form.GraphGroupingCombo.ItemIndex:=Form.GraphGroupingCombo.Items.IndexOf('Units'); Form.ViewChange(Form.GraphGroupingCombo);
            Form.GraphMouseDown(Form.GraphPaint,TMouseButton.mbLeft,[],20,20);
            Check((Form.WorkspaceTabs.ActiveTab=Form.DetailsTab) and (Form.DetailsList.Items.Count>0) and (Pos('Group:',Form.DetailsMemo.Text)>0),'Selecting a collapsed graph group opens its member/evidence list');
            Form.DetailsList.ItemIndex:=0; Form.DetailsObjectClick(nil);
            Check(Form.WorkspaceTabs.ActiveTab=Form.ExplainTab,'Group member opens its canonical object explanation');
            Form.GraphGroupingCombo.ItemIndex:=0; Form.SearchEdit.Text:='Click'; Form.ExplorerList.ItemIndex:=0; Form.ExplorerClick(nil);
            Form.WholeProgramGraphClick(nil);
            Check((Form.GraphCombo.ItemIndex=0) and (Form.WorkspaceTabs.ActiveTab=Form.GraphTab),'Whole program command opens startup execution projection');
            Check(Pos('Main.TMain.Click',Form.InspectorMemo.Text)>0,'Whole program projection preserves the inspected object context');
            Form.AllFormsGraphClick(nil);
            Check((Form.GraphCombo.ItemIndex=Form.GraphCombo.Items.IndexOf('Form navigation')) and (Form.WorkspaceTabs.ActiveTab=Form.GraphTab),'All forms command selects the whole form navigation projection');
            Check(Pos('Main.TMain.Click',Form.InspectorMemo.Text)>0,'All forms graph preserves the inspected object context');
            Form.AllDataGraphClick(nil);
            Check((Form.GraphCombo.ItemIndex=Form.GraphCombo.Items.IndexOf('Data flow')) and (Form.WorkspaceTabs.ActiveTab=Form.GraphTab),'Project data command opens the whole captured data projection');
            Check(Pos('Main.TMain.Click',Form.InspectorMemo.Text)>0,'Project data projection preserves the inspected object context');
            Form.BookmarkClick(nil); Form.BookmarksClick(nil); Check(Form.ExplorerList.Items.Count=1,'Canonical selection can be bookmarked');
            for Kind in ['Execution','Procedure CFG','Caller / callee','Form navigation','Data flow','Change impact'] do begin Form.GraphCombo.ItemIndex:=Form.GraphCombo.Items.IndexOf(Kind); Form.ViewChange(nil); end;
            Form.WorkspaceTabs.ActiveTab:=Form.OverviewTab; Form.Show; Application.ProcessMessages;
            Bitmap:=TBitmap.Create(Form.ClientWidth,Form.ClientHeight); try
              if Bitmap.Canvas.BeginScene then try Form.PaintTo(Bitmap.Canvas); finally Bitmap.Canvas.EndScene; end;
              if ParamStr(2)<>'no-report' then Bitmap.SaveToFile(TPath.Combine(Root,'docs\wp4-workspace.png')); finally Bitmap.Free; end;
            Form.WorkspaceTabs.ActiveTab:=Form.DetailsTab; Application.ProcessMessages;
            Bitmap:=TBitmap.Create(Form.ClientWidth,Form.ClientHeight);
            try
              if Bitmap.Canvas.BeginScene then try Form.PaintTo(Bitmap.Canvas); finally Bitmap.Canvas.EndScene; end;
              Bitmap.SaveToFile(TPath.Combine(Work,'details-native.png'));
            finally Bitmap.Free; end;
            Form.WorkspaceTabs.ActiveTab:=Form.ScreenTab;
            for Kind in ['Thumbnail','Fit','Native','Custom zoom','Full screen'] do begin
              Form.ScreenModeCombo.ItemIndex:=Form.ScreenModeCombo.Items.IndexOf(Kind); Form.ViewChange(nil); Application.ProcessMessages;
              Bitmap:=Form.ScreenPaint.MakeScreenshot; try Check((Bitmap.Width>0) and (Bitmap.Height>0),'Render screen mode '+Kind); finally Bitmap.Free; end;
            end;
            Check(not Form.HeaderLayout.Visible and not Form.ExplorerLayout.Visible and
              not Form.InspectorLayout.Visible and (Form.BorderStyle=TFmxFormBorderStyle.None),
              'Dedicated full screen hides surrounding workspace while retaining screen toolbar');
            EscapeKey:=vkEscape; EscapeChar:=#0; Form.FormKeyDown(nil,EscapeKey,EscapeChar,[]);
            Check(Form.HeaderLayout.Visible and Form.ExplorerLayout.Visible and Form.InspectorLayout.Visible and
              (EscapeKey=0),'Escape restores workspace from focused full screen');
            Form.ScreenModeCombo.ItemIndex:=2; Form.ViewChange(nil); SavedScreenWidth:=Form.ScreenPaint.Width;
            Form.ScreenZoom.Value:=300; Form.ViewChange(Form.ScreenZoom);
            Check((Form.ScreenModeCombo.ItemIndex=3) and (Abs(Form.ScreenPaint.Width-SavedScreenWidth*3)<1),
              'Custom zoom updates scrollable extent to three times native width');
            Form.ScreenModeCombo.ItemIndex:=1; Form.ViewChange(nil);
            Check((Form.ScreenPaint.Width<=Form.ScreenScroll.Width) and (Form.ScreenPaint.Height<=Form.ScreenScroll.Height),
              'Fit computes bounds from all captured components within screen viewport');
            Bitmap:=TBitmap.Create(320,160);
            try Bitmap.Clear(TAlphaColors.Blue); Bitmap.SaveToFile(TPath.Combine(Work,'runtime-evidence.png')); finally Bitmap.Free; end;
            with TDPHKnowledgeStore.Create(Request.Database,Fixture,TPath.Combine(Root,'migrations')) do
            try ImportScreenshot(Generation,TPath.Combine(Work,'runtime-evidence.png'),'Fixture contributor','Synthetic test image, not target runtime',ComponentKey);
              Form.LoadScreenshots(ScreenshotsJSON);
            finally Free; end;
            Check((Form.ScreenshotList.Count=1) and not Form.ScreenshotList.ListItems[0].ItemData.Bitmap.IsEmpty,
              'Imported screenshot gallery provides bounded image thumbnail');
            Form.ScreenshotList.ItemIndex:=0; Form.ScreenshotClick(nil);
            Form.ScreenshotModeCombo.ItemIndex:=1; Form.ScreenshotViewChange(nil);
            Check((Form.ScreenshotImage.Width=320) and (Form.ScreenshotImage.Height=160),
              'Native screenshot mode uses actual pixel dimensions');
            Form.ScreenshotZoom.Value:=200; Form.ScreenshotViewChange(Form.ScreenshotZoom);
            Check((Form.ScreenshotImage.Width=640) and (Form.ScreenshotImage.Height=320),
              'Screenshot zoom updates scrollable image bounds');
            Form.ScreenshotInspectClick(nil);
            Check((Form.WorkspaceTabs.ActiveTab=Form.ExplainTab) and Form.InspectorMemo.Text.StartsWith(View.Symbol(ComponentKey).GetValue<string>('name')),
              'Screenshot linked object opens canonical explanation');
            with TDPHKnowledgeStore.Create(Request.Database,Fixture,TPath.Combine(Root,'migrations')) do
            try
              TargetNote:=SaveKnowledge(0,0,Generation,'Target section fixture','Exact target revision fixture text','Fixture author','note','');
              RichLinks:=TJSONArray.Create;
              try
                for Kind in ['entity','relationship','evidence','screenshot','section'] do begin
                  FilterText:=''; if Kind='entity' then FilterText:='Main.TMain.Click' else if Kind='section' then FilterText:='Target section fixture';
                  Rows:=LinkCandidates(Generation,Kind,FilterText);
                  try Check(Rows.Count>0,'Link picker offers '+Kind+' candidates'); Row:=Rows.Items[0].Clone as TJSONObject;
                    Row.AddPair('link_role','cites'); RichLinks.AddElement(Row);
                  finally Rows.Free; end;
                end;
                LinkNote:=SaveKnowledge(0,0,Generation,'Multi-target section fixture','Fixture evidence only','Fixture author','note','','engineering','engineer',RichLinks.ToJSON);
              finally RichLinks.Free; end;
              Rows:=KnowledgeJSON;
              try TargetRevision:=Rows.Items[0].GetValue<Int64>('revision'); LinkRevision:=Rows.Items[1].GetValue<Int64>('revision');
                Check(Rows.Items[0].GetValue<TJSONArray>('backlinks').Count=1,'Exact document revision exposes current referring section backlink');
              finally Rows.Free; end;
              ReviewKnowledge(LinkNote,LinkRevision,Generation,'Fixture reviewer','verified');
              Form.LoadKnowledge(KnowledgeJSON);
            finally Free; end;
            Form.KnowledgeList.ItemIndex:=Form.KnowledgeList.Count-1; Form.KnowledgeClick(nil);
            Check(Form.KnowledgeLinksList.Count=5,'IDE-editable link list loads every saved typed target');
            Form.KnowledgeLinksList.ItemIndex:=0; Form.OpenKnowledgeLinkClick(nil);
            Check((Form.WorkspaceTabs.ActiveTab=Form.ExplainTab) and Form.InspectorMemo.Text.StartsWith('Main.TMain.Click'),
              'Saved entity link opens canonical source-backed explanation');
            Form.KnowledgeLinksList.ItemIndex:=1; Form.OpenKnowledgeLinkClick(nil);
            Check((Form.WorkspaceTabs.ActiveTab=Form.DetailsTab) and Form.DetailsMemo.Text.StartsWith('relationship:'),
              'Saved relationship link opens typed evidence details');
            Form.KnowledgeLinksList.ItemIndex:=2; Form.OpenKnowledgeLinkClick(nil);
            Check((Form.WorkspaceTabs.ActiveTab=Form.DetailsTab) and Form.DetailsMemo.Text.StartsWith('evidence:'),
              'Saved evidence link opens source range and derivation context');
            Form.KnowledgeLinksList.ItemIndex:=3; Form.OpenKnowledgeLinkClick(nil);
            Check(Form.WorkspaceTabs.ActiveTab=Form.ScreenshotTab,'Saved screenshot link opens its managed image');
            Form.KnowledgeLinksList.ItemIndex:=4; Form.OpenKnowledgeLinkClick(nil);
            Check((Form.WorkspaceTabs.ActiveTab=Form.DetailsTab) and Form.DetailsMemo.Text.Contains('Exact target revision fixture text'),
              'Saved section link opens exact pinned revision text');
            with TDPHKnowledgeStore.Create(Request.Database,Fixture,TPath.Combine(Root,'migrations')) do
            try
              SaveKnowledge(TargetNote,TargetRevision,Generation,'Target section fixture','Changed target revision fixture text','Fixture author','note','');
              Rows:=KnowledgeJSON;
              try Check((Rows.Items[1].GetValue<string>('pending')='1') and (Rows.Items[1].GetValue<string>('revision_state')='verified'),
                'Referenced section edit reopens separate review without rewriting prior verification');
              finally Rows.Free; end;
              Form.LoadKnowledge(KnowledgeJSON);
              Rows:=ReviewTasks(Generation);
              for Members:=0 to Rows.Count-1 do if Rows.Items[Members].GetValue<Int64>('knowledge_id')=LinkNote then Break;
              Form.LoadReviewTasks(Rows); Rows:=nil; Form.ReviewTasksList.ItemIndex:=Members; Form.ReviewTaskSelectionClick(nil);
            finally Free; end;
            Check(Form.ReviewAfterMemo.Text.Contains('Referenced section revision changed'),'Review queue explains referenced-document change');
            Form.WorkspaceTabs.ActiveTab:=Form.ReviewTasksTab; Application.ProcessMessages;
            Bitmap:=TBitmap.Create(Form.ClientWidth,Form.ClientHeight);
            try if Bitmap.Canvas.BeginScene then try Form.PaintTo(Bitmap.Canvas); finally Bitmap.Canvas.EndScene; end;
              Bitmap.SaveToFile(TPath.Combine(Work,'review-native.png'));
            finally Bitmap.Free; end;
            Form.ReviewTasksClick(Form.OpenReviewKnowledgeButton);
            Check(Form.KnowledgeBodyMemo.Text='Fixture evidence only','Review task opens affected authored content');
            Form.ReviewTasksClick(Form.ReviewImpactButton);
            Check((Form.WorkspaceTabs.ActiveTab=Form.GraphTab) and (Form.GraphCombo.Items[Form.GraphCombo.ItemIndex]='Change impact'),
              'Review task opens affected source change-impact projection');
            Form.ReviewReviewerEdit.Text:=''; Form.ReviewTasksClick(Form.VerifyTaskButton);
            Check(Form.StatusLabel.Text.Contains('named reviewer'),'Review task cannot record anonymous approval');
            Questions:=View.Questions;
            try
              Rows:=View.Questions; try Check((Rows.Count<=100) and (Rows.ToJSON=Questions.ToJSON),'Focused questions are bounded and deterministic for captured evidence'); finally Rows.Free; end;
              Row:=nil; for Members:=0 to Questions.Count-1 do if Questions.Items[Members].GetValue<string>('kind')='unresolved_relationship' then begin Row:=Questions.Items[Members] as TJSONObject; Break; end;
              Check((Row<>nil) and (Row.GetValue<string>('source_hash')<>'') and (Length(Row.GetValue<string>('id'))=64),
                'Unresolved call question carries actual source hash and stable evidence identity');
              QuestionID:=Row.GetValue<string>('id'); Form.QuestionsClick(Form.RefreshQuestionsButton); Form.QuestionsList.ItemIndex:=Members; Form.QuestionSelectionClick(nil);
              Form.QuestionsClick(Form.QuestionEvidenceButton);
              Check((Form.WorkspaceTabs.ActiveTab=Form.DetailsTab) and Form.DetailsMemo.Text.StartsWith('author_question:'),'Question opens source-backed evidence details');
              Form.QuestionsClick(Form.AnswerQuestionButton);
              Check((Form.WorkspaceTabs.ActiveTab=Form.KnowledgeTab) and Form.KnowledgeBodyMemo.Text.EndsWith('Answer:'+sLineBreak) and
                (Form.KnowledgeAuthorEdit.Text=''),'Question answer draft requires explicit named author and response');
              with TDPHKnowledgeStore.Create(Request.Database,Fixture,TPath.Combine(Root,'migrations')) do
              try
                Failed:=False; try SaveKnowledge(0,0,Generation,'Fixture answer','Question text'+sLineBreak+'Answer:','Fixture author','unknown',Row.GetValue<string>('entity_key'),'engineering','engineer','[]',Row.ToJSON); except Failed:=True; end;
                Check(Failed,'Empty answer cannot create an attributed response');
                AnswerID:=SaveKnowledge(0,0,Generation,'Fixture answer','Question: '+Row.GetValue<string>('prompt')+sLineBreak+'Answer: Fixture-only statement; not runtime evidence.',
                  'Fixture author','unknown',Row.GetValue<string>('entity_key'),'engineering','engineer','[]',Row.ToJSON);
                Rows:=KnowledgeJSON;
                try AnswerRevision:=Rows.Items[Rows.Count-1].GetValue<Int64>('revision'); RichLinks:=View.Questions(Rows);
                  try FoundChild:=False; for V in RichLinks do if V.GetValue<string>('id')=QuestionID then FoundChild:=True;
                    Check(FoundChild,'Saved but unreviewed answer does not hide its author question');
                  finally RichLinks.Free; end;
                finally Rows.Free; end;
                ReviewKnowledge(AnswerID,AnswerRevision,Generation,'Fixture reviewer','verified');
                Rows:=KnowledgeJSON;
                try RichLinks:=View.Questions(Rows);
                  try FoundChild:=False; for V in RichLinks do if V.GetValue<string>('id')=QuestionID then FoundChild:=True;
                    Check(not FoundChild,'Explicitly verified response suppresses only its exact evidence question');
                  finally RichLinks.Free; end;
                finally Rows.Free; end;
              finally Free; end;
              Form.DiscardKnowledgeClick(nil);
            finally Questions.Free; end;
            NativeStore:=TDPHKnowledgeStore.Create(Request.Database,Fixture,TPath.Combine(Root,'migrations'));
            try
              TranslationNote:=NativeStore.SaveKnowledge(0,0,Generation,'Translation demonstration','Run conversion','Fixture author','note','','engineering','engineer');
              Rows:=NativeStore.KnowledgeJSON;
              try TranslationRevision:=0; for V in Rows do if V.GetValue<Int64>('id')=TranslationNote then TranslationRevision:=V.GetValue<Int64>('revision'); finally Rows.Free; end;
              TranslationProvider:=TDPHAtlasAdapter.Create(TPath.Combine(Root,'samples\translation\DPH.fr.sample.json'));
              TranslationCache:=TDPHTranslationCache.Create(NativeStore);
              try J:=TranslationCache.Translate(TranslationRevision,'en','fr',TDPHTranslationCache.SegmentsForText('Run conversion'),TranslationProvider); J.Free;
              finally TranslationCache.Free; TranslationProvider:=nil; end;
              Form.LoadKnowledge(NativeStore.KnowledgeJSON);
              for Members:=0 to Form.KnowledgeList.Count-1 do if Form.KnowledgeList.Items[Members].Contains('Translation demonstration') then Form.KnowledgeList.ItemIndex:=Members;
              Form.KnowledgeClick(nil); Form.LoadTranslations(NativeStore.TranslationEntries(TranslationRevision));
              Check((Form.TranslationList.Count=1) and Form.TranslationMemo.Text.Contains('LOCALIZED PROSE') and Form.TranslationMemo.Text.Contains('Atlas-DAT-offline'),
                'Native translation view compares source and actual cached DAT prose with provider provenance');
              Check(Form.TranslationMemo.ReadOnly and Form.TranslationMemo.WordWrap and Form.TranslationStatus.Text.Contains('needs_review'),
                'Native translated content wraps, remains read-only and exposes review state');
              Form.WorkspacePageCombo.ItemIndex:=Form.WorkspacePageCombo.Items.IndexOf('Translations'); Form.WorkspacePageChange(Form.WorkspacePageCombo);
              Check(Form.WorkspaceTabs.ActiveTab=Form.TranslationTab,'Top-right page selector reaches the IDE-editable Translations page');
              Application.ProcessMessages; Bitmap:=TBitmap.Create(Form.ClientWidth,Form.ClientHeight);
              try if Bitmap.Canvas.BeginScene then try Form.PaintTo(Bitmap.Canvas); finally Bitmap.Canvas.EndScene; end;
                Bitmap.SaveToFile(TPath.Combine(Root,'docs\completion-translations-native.png'));
              finally Bitmap.Free; end;
              Form.NewKnowledgeClick(nil); Check(Form.TranslationList.Count=0,'New source section clears prior localized content instead of reusing its review');
            finally NativeStore.Free; end;
            TranslationRequest:=Request; TranslationRequest.Command:='translate'; TranslationRequest.ExpectedRevision:=TranslationRevision;
            TranslationRequest.Kind:='en'; TranslationRequest.Audience:='fr'; TranslationRequest.LinksJSON:='{}';
            TranslationRequest.Body:=TPath.Combine(Root,'samples\translation\DPH.fr.sample.json'); Worker.Submit(TranslationRequest); Response:=WaitResponse;
            try Check(not Response.Failed and (Response.Translations<>nil) and (Response.TranslationRevision=TranslationRevision),
              'Background worker loads the exact revision translation through the DAT adapter and persistent cache'); finally Response.Free; end;
            TranslationRequest:=Request; TranslationRequest.Command:='publish'; TranslationRequest.GenerationID:=Generation;
            TranslationRequest.ExportDirectory:=TPath.Combine(Work,'validation-bundle'); TranslationRequest.Audience:='all';
            TranslationRequest.IncludeSourceNavigation:=True;
            Worker.Submit(TranslationRequest); Response:=WaitResponse;
            try Check(not Response.Failed and (Response.ExportDirectory<>''),'Background publisher creates a fixture bundle for native validation'); finally Response.Free; end;
            Check(not Form.PublishSourceNavigation.IsChecked and not Form.PublishAgentInstructions.IsChecked,
              'Source browsing and generated agent boundaries require separate explicit export opt-ins');
            TranslationRequest:=Default(TDPHWorkspaceRequest); TranslationRequest.Command:='validate_bundle';
            TranslationRequest.ExportDirectory:=TPath.Combine(Work,'validation-bundle'); TranslationRequest.Title:=View.Document.GetValue<string>('semantics.input_fingerprint');
            TranslationRequest.AllowStaleBundle:=True; Worker.Submit(TranslationRequest); Response:=WaitResponse;
            try Check(not Response.Failed and Response.ValidationReport.Contains('Historical/partial inspection enabled'),
              'Standalone background bundle validation works without opening a database and qualifies historical inspection');
              ValidationReportText:=Response.ValidationReport; Form.ValidationMemo.Text:=ValidationReportText;
            finally Response.Free; end;
            Form.ValidateBundleClick(Form.ValidationUseCaptureButton);
            Check(Form.ValidationFingerprintEdit.Text=View.Document.GetValue<string>('semantics.input_fingerprint'),
              'Native validation explicitly copies expected identity from the opened capture');
            Form.WorkspacePageCombo.ItemIndex:=Form.WorkspacePageCombo.Items.IndexOf('Validate bundle'); Form.WorkspacePageChange(Form.WorkspacePageCombo);
            Check((Form.WorkspaceTabs.ActiveTab=Form.ValidationTab) and not Form.ValidationAllowStale.IsChecked and Form.ValidationMemo.ReadOnly,
              'Native validation is reachable, defaults to current-only and displays read-only reports');
            Form.ValidationMemo.Text:=ValidationReportText;
            Form.ValidationAllowStale.IsChecked:=True;
            Application.ProcessMessages; Bitmap:=TBitmap.Create(Form.ClientWidth,Form.ClientHeight);
            try if Bitmap.Canvas.BeginScene then try Form.PaintTo(Bitmap.Canvas); finally Bitmap.Canvas.EndScene; end;
              Bitmap.SaveToFile(TPath.Combine(Root,'docs\completion-bundle-validation-native.png'));
            finally Bitmap.Free; end;
            TranslationRequest.AllowStaleBundle:=False; Worker.Submit(TranslationRequest); Response:=WaitResponse;
            try Check(Response.Failed,'Default bundle validation rejects a partial/stale capture'); finally Response.Free; end;
            TranslationRequest.AllowStaleBundle:=True; TranslationRequest.Title:=StringOfChar('0',64); Worker.Submit(TranslationRequest); Response:=WaitResponse;
            try Check(Response.Failed,'Background validation rejects a different expected fingerprint'); finally Response.Free; end;
            TranslationRequest.Title:=View.Document.GetValue<string>('semantics.input_fingerprint');
            TFile.AppendAllText(TPath.Combine(Work,'validation-bundle\indexes\symbols.jsonl'),'tamper',TEncoding.UTF8);
            Worker.Submit(TranslationRequest); Response:=WaitResponse;
            try Check(Response.Failed,'Background validation rejects changed bundle bytes'); finally Response.Free; end;
            Form.ValidationFingerprintEdit.Text:='invalid'; Form.ValidateBundleClick(Form.ValidationSelectButton);
            Check(Form.ValidationMemo.Text.Contains('64-character'),'Native validation explains malformed expected fingerprints before file selection');

            Form.ScreenshotInspectClick(nil);
            Form.BookmarkClick(nil); Form.WorkspaceTabs.ActiveTab:=Form.GraphTab;
            Form.LoadView(View.Document.Clone as TJSONObject);
            Check((Form.WorkspaceTabs.ActiveTab=Form.GraphTab) and
              Form.InspectorMemo.Text.StartsWith(View.Symbol(ComponentKey).GetValue<string>('name')),
              'Same-project reassessment preserves selected object and active page');
            Form.BookmarksClick(nil);
            Check(Form.ExplorerList.Items.Contains(View.Symbol(ComponentKey).GetValue<string>('name')),
              'Same-project reassessment retains surviving bookmarks');
            J:=View.Document.Clone as TJSONObject;
            Rows:=J.GetValue<TJSONArray>('semantics.symbols');
            for Members:=Rows.Count-1 downto 0 do if Rows.Items[Members].GetValue<string>('key')=ComponentKey then Rows.Remove(Members).Free;
            Form.LoadView(J);
            Check((Form.InspectorMemo.Text='') and Form.StatusLabel.Text.Contains('absent'),
              'Removed object clears stale inspector and reports selection loss without guessing a replacement');
            Form.BookmarksClick(nil);
            Check(not Form.ExplorerList.Items.Contains(View.Symbol(ComponentKey).GetValue<string>('name')),
              'Removed object is pruned from reassessment bookmarks');
            Form.Hide;
          finally Form.Free; end;
          CachedShownBeforeVerification:=False;
          Request.Command:='open'; Worker.Submit(Request); Watch:=TStopwatch.StartNew; Response:=WaitResponse;
          try Check(not Response.Failed and (Response.Document<>nil),'Cached database opens without analysis'); Check(not Response.Detached and (Response.SourceEntry<>''),'Cached open verifies available source automatically');
            Check(Response.Document.GetValue<Int64>('generation_id')=Generation,'Cached open preserves generation'); Check(Watch.ElapsedMilliseconds<5000,'Fixture cached open completes within 5 seconds'); finally Response.Free; end;
          Check(CachedShownBeforeVerification,'Cached document is delivered before background verification completes');
          TFile.Move(Request.Entry,Request.Entry+'.offline');
          try
            Worker.Submit(Request); Response:=WaitResponse;
            try Check(not Response.Failed and Response.Detached and (Response.Document<>nil),'Unavailable source opens safely detached'); finally Response.Free; end;
          finally TFile.Move(Request.Entry+'.offline',Request.Entry); end;
          Request.Command:='check'; Worker.Submit(Request); Response:=WaitResponse;
          try Check(not Response.Failed and not Response.Changed and (Response.Document=nil),'Unchanged connected check skips analysis'); finally Response.Free; end;
          Request.Defines:=['EXTRA']; Worker.Submit(Request); Response:=WaitResponse;
          try Check(not Response.Failed and (Response.Document<>nil),'Configuration change reassesses unchanged source bytes'); finally Response.Free; end;
          TFile.AppendAllText(TPath.Combine(Fixture,'Main.pas'),sLineBreak+'// controlled workspace test'+sLineBreak,TEncoding.UTF8);
          Worker.Submit(Request); Response:=WaitResponse;
          try Check(not Response.Failed and Response.Changed and (Response.Document<>nil),'Source modification triggers background reassessment'); finally Response.Free; end;
          After:=THashSHA2.GetHashStringFromFile(TPath.Combine(Fixture,'Main.pas'));
          Check(Before<>After,'Controlled edit changes its input fingerprint');
          Request.Command:='open'; Worker.Submit(Request); Response:=WaitResponse; try Check(not Response.Failed,'Updated cached workspace can reopen'); finally Response.Free; end;
          Path:=TPath.Combine(Request.Database+'.views',THashSHA2.GetHashString(View.Document.ToJSON)+'.json'); TFile.AppendAllText(Path,'tamper',TEncoding.UTF8);
          // Explicitly select the damaged generation rather than whichever head is current.
          with TDPHKnowledgeStore.Create(Request.Database,Fixture,TPath.Combine(Root,'migrations')) do
          try Failed:=False; try LoadWorkspaceView(Generation); except Failed:=True; end; Check(Failed,'Artifact tampering is rejected'); finally Free; end;
        finally View.Free; end;
      finally Worker.Free; end;
      Check(True,'Idle worker shutdown returns without a queue loop');
      J:=TJSONObject.Create; try J.AddPair('checks_passed',TJSONNumber.Create(Checks)); J.AddPair('corpus','copied semantic fixture'); J.AddPair('work',Work);
        if ParamStr(2)<>'no-report' then TFile.WriteAllText(TPath.Combine(Root,'docs\wp4-validation.json'),J.Format,TEncoding.UTF8); finally J.Free; end;
      Writeln('PASS WP4: ',Checks,' checks');
    except on E: Exception do begin Writeln(E.ClassName,': ',E.Message); ExitCode:=1; end; end;
  finally CoUninitialize; end;
end.
