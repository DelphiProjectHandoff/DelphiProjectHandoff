DELPHI PROJECT HANDOFF 0.8.0.11 - EDITABLE SOURCE DISTRIBUTION

This archive contains the Delphi application source, editable FMX forms,
project and resource files, database migrations, the local HTML help, graphics,
guide source, guide illustrations, the OrderPractice example, all 35 offline
interface language packs, the experimental bundled English-to-German project-text
model, and the bundled build dependencies. It contains no personal .dphdb databases,
Git history, or compiled DPH executable.

TO BUILD
1. Extract the entire ZIP into a writable local folder. Do not build in the ZIP.
2. Before opening the main form in RAD Studio 37, choose Component > Install
   Packages > Add and select the supplied DAT FMX design BPL under
   export\DAT-component-kit\DelphiProjectHandoff\DesignPackages\Win32\Release.
   Keep its adjacent runtime BPLs. The project already includes the DAT source
   search path; there is no separate dependency preparation command. See
   export\DAT-component-kit\DelphiProjectHandoff\README.txt for details.
3. Open DelphiProjectHandoff.dproj. Select Win64 or Win32 and Release; Build.
4. Find the executable in bin\Win64\Release or bin\Win32\Release. Keep the
   corresponding WebView2Loader.dll beside it. The project copies that loader
   automatically after a successful build.
5. Run the executable from the extracted project folder. Keep migrations,
   help, images and icons, and Localization in that folder. The German project-text
   trial reads its WebAssembly model from Localization\OfflineTranslation without Internet access.
   See docs\guides\Run_And_Test.txt
   for the application's first-use and validation steps.

The Microsoft WebView2 Runtime is required for embedded HTML learning views.
LibreOffice at its standard Windows path is needed to extract text from PDF,
legacy Word, RTF and several other older word-processing formats.
The selected Delphi application is read as input; DPH does not run or modify it.
Start with Handoff dossier. A new capture remains temporary until the user
clicks Save project, or chooses Yes at close or on a project change. The save
dialog starts in DPH's databases folder and suggests a dated name if an older
save already has the project name; a confirmation shows the full saved path.
Keep the .dphdb and adjacent .dphdb.views folder together. On failure,
DPH reports the error and retains the temporary capture. No discards the
capture and Cancel keeps it open. Rescan project checks attached source for changes.
The dossier maps captured directories and project build paths and links component
and database evidence. Generated form views are reconstructions, not runtime
screenshots.
The Read public websites checkbox is off by default and controls optional
HTTPS requests for public sites referenced in selected project documents.
The included third-party dependency folders contain their own license files.

SHA256.txt lists every packaged source file and its SHA-256 digest. The
DelphiProjectHandoff.res file is part of the source release because the
DelphiProjectHandoff.dpr file references it.