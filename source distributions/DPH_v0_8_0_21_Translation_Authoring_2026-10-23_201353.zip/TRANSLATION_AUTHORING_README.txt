DELPHI PROJECT HANDOFF 0.8.0.21 - OPTIONAL TRANSLATION AUTHORING FILES

This ZIP holds 35 translation-project JSON files under Localization\Development.
They are for developers editing language packs with Delphi App Translation
Studio. They are not needed to install DPH, run either Windows edition, or
build the application from the matching editable-source ZIP.

If you plan to edit translations, extract the matching source ZIP first.
Then extract this ZIP into the same folder, preserving the
Localization\Development directory. Do not replace the 35 runtime language
packs in Localization\Languages with these authoring projects.

The matching source ZIP includes the IDE-editable forms, design package,
runtime language packs, dependencies, guides, and build instructions.