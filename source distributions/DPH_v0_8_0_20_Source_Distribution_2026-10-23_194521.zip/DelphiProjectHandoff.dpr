program DelphiProjectHandoff;

uses
  System.StartUpCopy,
  FMX.Forms,
  DPH.UI.Main in 'DPH.UI.Main.pas' {DPHMainForm},
  DPH.UI.Progress in 'DPH.UI.Progress.pas' {DPHProgressForm},
  DPH.UI.SavePrompt in 'DPH.UI.SavePrompt.pas' {DPHSavePromptForm},
  DPH.Storage.Types in 'DPH.Storage.Types.pas',
  DPH.Storage.Database in 'DPH.Storage.Database.pas',
  DPH.Storage.Backup in 'DPH.Storage.Backup.pas',
  DPH.Parse.Model in 'DPH.Parse.Model.pas',
  DPH.Project.Source in 'DPH.Project.Source.pas',
  DPH.Parse.Lexer in 'DPH.Parse.Lexer.pas',
  DPH.Parse.Preprocessor in 'DPH.Parse.Preprocessor.pas',
  DPH.Parse.Pascal in 'DPH.Parse.Pascal.pas',
  DPH.Parse.Resources in 'DPH.Parse.Resources.pas',
  DPH.Parse.Forms in 'DPH.Parse.Forms.pas',
  DPH.Project.Inventory in 'DPH.Project.Inventory.pas',
  DPH.Project.Analysis in 'DPH.Project.Analysis.pas',
  DPH.Analysis.Model in 'DPH.Analysis.Model.pas',
  DPH.Analysis.Symbols in 'DPH.Analysis.Symbols.pas',
  DPH.Analysis.Flow in 'DPH.Analysis.Flow.pas',
  DPH.Analysis.Async in 'DPH.Analysis.Async.pas',
  DPH.Analysis.SQL in 'DPH.Analysis.SQL.pas',
  DPH.Workspace.Graphs in 'DPH.Workspace.Graphs.pas',
  DPH.Analysis.Persistence in 'DPH.Analysis.Persistence.pas',
  DPH.Workspace.Model in 'DPH.Workspace.Model.pas',
  DPH.Workspace.Catalog in 'DPH.Workspace.Catalog.pas',
  DPH.Workspace.Worker in 'DPH.Workspace.Worker.pas',
  DPH.Workspace.Screen in 'DPH.Workspace.Screen.pas',
  DPH.Publish.Model in 'DPH.Publish.Model.pas',
  DPH.Publish.Export in 'DPH.Publish.Export.pas',
  DPH.Publish.Translation in 'DPH.Publish.Translation.pas',
  DPH.Publish.BrowserPolicy in 'DPH.Publish.BrowserPolicy.pas',
  DPH.Publish.OfflinePreview in 'DPH.Publish.OfflinePreview.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TDPHMainForm, DPHMainForm);
  Application.Run;
end.
