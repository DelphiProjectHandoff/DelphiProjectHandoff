@echo off
setlocal
cd /d "%~dp0.."
call "C:\Program Files (x86)\Embarcadero\Studio\37.0\bin\rsvars.bat"
if errorlevel 1 exit /b 1
dcc32 -B -Q -U"%BDS%\lib\Win32\release;." -NSSystem;FMX;Data;Xml;Winapi -N0dcu\Win32\Debug -Ebin\Win32\Debug tests\DPH.Tests.Selection.dpr
if errorlevel 1 exit /b 1
bin\Win32\Debug\DPH.Tests.Selection.exe "%CD%"
if errorlevel 1 exit /b 1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$report=Get-Content -LiteralPath 'docs\selection-validation.json' -Raw | ConvertFrom-Json; & 'bin\Win32\Debug\DPH.Tests.Selection.exe' $report.self_cache; exit $LASTEXITCODE"
exit /b %errorlevel%
