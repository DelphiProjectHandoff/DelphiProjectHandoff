from pathlib import Path
import subprocess,json,hashlib
r=Path.cwd();g=r'C:\Program Files\Git\cmd\git.exe'
def read(*a):return subprocess.check_output([g,*a]).decode()
def run(*a):subprocess.run([g,*a],check=True)
lock=r/'.git/index.lock'
if lock.exists():
 processes=subprocess.check_output(['powershell','-NoProfile','-Command',"@(Get-Process git -ErrorAction SilentlyContinue).Count"]).decode().strip();assert lock.stat().st_size==0 and processes=='0';lock.unlink()
assert read('rev-parse','HEAD').strip().startswith('34b26c3')
for remote in ['origin','private']:
 run('fetch',remote);assert read('rev-list','--left-right','--count','HEAD...'+remote+'/main').split()==['0','0']
# Existing staging belongs to this exact intended batch; checked below.
e=json.loads((r/'docs/phase1-target-recovery-completion-validation.json').read_text());files=list(e['evidence_hashes'])+['docs/phase1-target-recovery-completion-validation.json']
for f,h in e['evidence_hashes'].items():assert hashlib.sha256((r/f).read_bytes()).hexdigest()==h,f
run('diff','--check');run('add','--',*files)
assert set(read('diff','--cached','--name-only').splitlines())==set(files)
run('diff','--cached','--check');run('diff','--cached','--stat')
run('commit','-m','Add target backup and restoration requirements for 05.20')
for remote in ['origin','private']:run('push',remote,'HEAD:main')
head=read('rev-parse','HEAD').strip()
for remote in ['origin','private']:assert read('ls-remote',remote,'refs/heads/main').split()[0]==head
assert not read('diff','--name-only').strip();assert not read('diff','--cached','--name-only').strip()
print('Both remotes verified:',head);print(read('status','--short'))
