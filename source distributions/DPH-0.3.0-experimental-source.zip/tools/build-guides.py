"""Build DPH's own guides from implemented contracts and inspected source."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parent.parent
GUIDES = ROOT / 'docs' / 'guides'
GUIDES.mkdir(parents=True, exist_ok=True)

USER = [
('Purpose and evidence', [
'Delphi Project Handoff explains an explicitly selected Delphi project through source inventory, form information, symbols, relationships, control flow and attributed knowledge. It stores its work in one SQLite knowledge database per selected project. DPH is experimental Windows desktop software. Its static analysis is not a Delphi compiler and does not prove every runtime behavior.',
'Use the generation number, source hashes, certainty labels and diagnostics together. A complete captured analysis means the implemented analysis stages accepted their captured inputs. It does not mean a human approved the business explanation. PARTIAL means unavailable dependencies, unsupported syntax or bounded analysis prevented full coverage. DPH does not compile or execute the selected project, run its build scripts, load its component classes or connect to its production services.'
]),
('Start DPH', [
'Start DelphiProjectHandoff.exe from its deployed folder. Keep the migrations folder and Microsoft WebView2 loader with the deployment. WebView2 Runtime supports the optional embedded HTML preview. An unavailable preview must leave the exported HTML usable independently. The initial validated target is Windows Win32; another operating system has not been validated.',
'The Getting started page opens before a project is loaded. It explains the first ten minutes, each workspace tab, a small learning exercise, Delphi terms and repeatable checks. The header Getting started button returns to it at any time. Its native text fallback remains available without WebView2. Keep the help folder with the deployment.',
'DPH opens maximized to fill the available Windows desktop. The far-left list contains project objects, the centre contains workspace tabs, and the right-hand pane is labeled Selection details. Double-click an object in the far-left list to read its identity, signature and source location on the right. Its text wraps to fit; scroll inside the pane for more. Click the central Explain tab for behavior or Source for code. Drag either vertical divider to resize the panes. In a smaller restored window, scroll horizontally below the top command buttons to reach commands that do not fit.',
'Read current activity and captured status on the line along the bottom edge of the window. To read analysis gaps, click the Learn the project tab in the centre, then click Coverage and troubleshooting in that tab\'s topic list. PARTIAL means incomplete evidence. The last successfully opened database identity is remembered in the local user profile and reopens detached.'
]),
('Attach a source project', [
'Click Attach project at the top and select the application you want to document using its dproj, dpr or groupproj file. DPH rejects its own project, including renamed copies retaining its GUID or program declaration. The current workspace stays loaded when a selection is rejected. Choose a database filename ending in dphdb. The save dialog defaults to Databases under the Handoff application folder: the top-level Databases folder in the source checkout, or beside the executable in an extracted distribution. Existing databases are not moved. You may browse elsewhere outside the selected source folder. DPH rejects database and export locations inside the source boundary and rejects reparse paths that could bypass that boundary. Keep each selected project in its own database.',
'Select Debug or Release and Win32 or Win64 as appropriate before analysis. Win64 is an analysis configuration choice; the current DPH executable is built for Win32. Extra defines use semicolons. Explicit dependency roots also use semicolons. Add only roots you intend to permit DPH to read. A missing dependency is a visible gap, not a reason to let discovery search neighboring projects without a boundary.',
'For the pinned VCL2FMXConverter Win32 reference, enter MSWINDOWS;WIN32 as extra defines to reproduce the recorded baseline. DPH does not synthesize every compiler built-in from the platform label. Supply the symbols required by the selected compiler environment; unknown conditional expressions remain uncertain.',
'Analysis runs in the background. Explorer data belongs to its displayed generation while the worker prepares another. Changed inputs during a scan supersede the capture and request reassessment. A partial or failed capture does not replace a previous complete published head. DPH retains the evidence needed to inspect partial results honestly.'
]),
('Open cached work', [
'Click Open cache at the top to inspect a saved dphdb database. The picker defaults to Databases under the Handoff application folder; browse to your existing database if it is elsewhere. DPH validates the cached workspace artifact against its SHA256 and generation before displaying it. Cached identity facts also reject old self-analysis databases without relying on their filename or the original source being present. A rejected cache leaves the current workspace intact. A rejected remembered or command-line startup cache leaves Getting started visible. Cached opening does not start a source scan. The cache opens detached until you explicitly attach its source project.',
'Detached mode allows historical inspection and authored notes. It does not follow cached filesystem paths to display source text or approve a current-source review. Attach the source when you want live hash checks, source navigation and human verification against current evidence. A missing or damaged cached artifact is reported rather than silently treated as a current view.'
,'A damaged supplemental screenshot does not block opening valid cached analysis. DPH reports Screenshot evidence unavailable and omits the rejected image from display. Repair or restore its managed evidence before publishing a bundle that uses it; do not replace its hash to disguise damaged content.'
,'Keep a copied database with its adjacent database.dphdb.views folder. DPH resolves cache files beside the opened database and verifies their hashes instead of following old absolute artifact paths. To move the source project, choose Relocate verified source and select the same project entry. Exact file identities, content hashes, availability and analysis selection must match the captured generation. A different copy is rejected. Accepted relocation preserves logical symbols and notes, requests human review and reassesses the new context.'
]),
('Learn the selected project', [
'Begin with Learn the project rather than trying to interpret the complete symbol index. Start here gives a six-step route: read actual startup statements, identify a familiar screen control, follow its event into code, inspect decisions and data, check gaps, then plan a controlled maintenance change. Each topic describes how to read the evidence and supplies project-specific starting points.',
'How the program starts quotes parsed program-body expressions with source locations and hashes. It does not substitute the first routine in a graph for the entry point. Screens and user actions links declared components. Follow an event explains binds, calls, callbacks and possible scheduling. Architecture, data and maintenance topics explain what their relationship kinds mean and where conclusions remain unsupported.',
'Double-click an Explorer object or follow a learning link to open Explain. It presents the declared contract, nearby source-author comments when captured, callers and consumers, outgoing interactions, decisions, attributed knowledge and a bounded execution trace. Source comments remain author documentation, not independently verified behavior. Expand a connection to see the precise evidence and derivation rule.',
'The learning and Explain pages run locally through WebView2. If the runtime is unavailable, a readable text fallback remains. Local learning projections avoid export-only redaction work; the publisher refuses to export them. A separately constructed publication model always applies redaction and exclusions.'
]),
('Explore and search', [
'Double-click an object in the far-left Explorer list to select it. Selection details on the right shows its name, kind, signature, declared type, source location, generation and evidence hash. Open the central Explain tab for behavior and serialized properties when captured. Units, types, components and routines provide drill-down scopes. The breadcrumb reports the active scope and page. Parent moves upward; Back restores a prior selection.',
'Search matches object names, kinds and signatures across the project. A kind filter narrows the result. Pages contain at most 250 objects; Next page advances the result set. Clear the search or use Parent to broaden your route. Bookmark records the current canonical selection, and Bookmarks displays those selections. Bookmarks belong to the captured generation and reset when a new generation is loaded.',
'The References tab lists forward and reverse relationships with their certainty and derivation labels. Double-click a resolvable related object to inspect it. An unresolved target remains unresolved; the relationship is not proof that a named method actually ran.'
]),
('Read source and graph evidence', [
'The Source tab reads the attached source file and compares its bytes with the captured SHA256 before applying the source range. If the live file changed or cannot be decoded, DPH displays a stale or unavailable message instead of presenting the old range as a confirmed live location. External dependencies remain in the evidence model but are not followed by the local source viewer through an invented path.',
'The Graphs tab offers Execution, Procedure CFG, Caller / callee, Form navigation, Data flow and Change impact. Select a relevant routine or component before choosing a narrow graph. Graphs show at most 120 nodes and 960 edges. A narrower selection is preferable to interpreting a truncated large view as the complete program.',
'Confirmed static edges use blue. Uncertain edges use orange. Procedure CFG opens a labeled source-derived diagram when WebView2 is available, with a native graph fallback. Large routines collapse ordinary straight-line statements while retaining control nodes; arrows identify omitted statements. More than 70 retained control nodes produces an explicit limit instead of a misleading complete diagram. Other graph views retain their 120-node bound. Form navigation does not prove runtime window activation; Change impact is possible reachability. Click a native graph node to inspect its evidence.'
]),
('Inspect screens', [
'The Form designs tab reconstructs rectangles and text from serialized FMX or DFM data. It never creates untrusted component classes. The result is explicitly an approximate design-time view, not an actual runtime screenshot. Custom painting, runtime geometry, styles and unavailable inherited resources may differ from the running program.',
'Thumbnail displays a gallery of up to 60 forms. Fit scales the selected form to the viewport, Native uses its reconstructed size, Zoom displays 200 percent, and Full screen uses the larger window. The Full screen button toggles the DPH window size. Click a component rectangle to navigate to the corresponding canonical object when a source association is available.'
]),
('Import actual screenshot evidence', [
'Open Screenshots, enter the named contributor and a description including capture date and environment, then choose Import an existing PNG screenshot. Select an image you already captured and are authorized to preserve. DPH does not launch the selected application. PNG files are bounded to 20 MiB, 8192 pixels per dimension and 32 million pixels.',
'The managed image and its metadata are checksummed beside the knowledge database. Select a row to view the actual image and attribution. Runtime origin, capture time and environment are contributor claims and remain user supplied unverified. The associated generation is displayed, including when it is historical. Copy the adjacent views folder when moving the database.',
'Publishing includes only imported images matching the exported generation and included object scope. Excluding a linked source excludes its screenshot. The exported caption identifies the contributor and unverified state; private storage paths are omitted. Review screenshots for confidential material before sharing.'
]),
('Write attributed knowledge', [
'Use the Knowledge tab for notes, business rules, engineering rules, user help, maintenance, build and deployment details, troubleshooting, orientation, decisions and unknowns. Select the relevant Explorer object before starting New to link the record to that object. With no selected object, a new record applies to the project.',
'Enter a stable title, choose its kind, supply a named author and write the body. Save creates a new immutable revision pending human review. Titles and kinds remain stable after creation; update the body, or create and retire a replacement. Selecting a saved row displays its text, links, current state and complete authored and review history.',
'Unsaved text survives a background refresh. Save or explicitly Discard edit before switching projects, selecting another record, starting another record or closing. DPH will not silently approve an old saved revision while different unsaved text is visible.'
]),
('Review and retire knowledge', [
'Enter the named reviewer and select a saved revision. Verify review records your explicit approval of that text against the captured generation. Reject records a rejected explanation. Retire preserves an obsolete record and its history while resolving its pending task. The Pending reviews only filter shows records that still need attention.',
'Source or configuration changes invalidate human review separately from analysis. A successful rescan preserves authored text but cannot approve it. When a linked method disappears or is renamed, DPH keeps the old link as historical evidence and refuses to transfer verified knowledge automatically. Investigate continuity and create the appropriate reviewed replacement.',
'Attribution is a local named-author record, not an enterprise authentication system. A verified human explanation records the reviewer decision; it does not establish unwritten historical business intent automatically. Detached review requires source attachment first.'
]),
('Publish manuals and handoffs', [
'Open Publish. Choose Full project or Selected object and context. The task choice requires a selected canonical object and includes its incident technical context rather than a blind truncation of a full export. Enter explicit relative file or folder exclusions separated by semicolons. External source roots and sensitive filename categories are excluded by default.',
'Choose a new export folder name outside the source tree. DPH refuses an existing destination to avoid overwriting unrelated files. It creates offline index.html, local assets, canonical.json, editable engineering and user guides, technical JSONL indexes, evidence references, coverage and a checksum manifest. Generated AGENTS.md and source snapshots are excluded unless a separate explicit request is implemented and authorized.',
'Preview offline HTML opens the approved local index and generated hash-named object explanation pages through Edge. External addresses and arbitrary file navigation are blocked. Offline search and internal links work without a translation service. Atlas is unconfigured. The GTranslate region is disabled in the offline edition, and the language-label helper is local. No external translation or AI service receives source through this feature.',
'Run tools/export-pdf.ps1 with the BundleDirectory parameter for optional PDF companions. It uses LibreOffice and the approved Python 3.13 with pypdf, populates cached TOC page numbers while retaining changeable fields, and refreshes bundle checksums. Read coverage and known unknowns before treating an export as a final operating manual. Automatic documentation cannot invent missing end-user procedures.'
]),
('Validate and preserve exports', [
'Run DPH.ValidateHandoff.exe with the bundle directory and a separately retained trusted input fingerprint. It rejects stale exports by default. Add --allow-stale only to inspect the integrity of a historical or partial bundle; the flag does not establish current or complete source evidence.',
'Validate artifact filenames and SHA256 values against validation/manifest-sha256.json. The manifest records generation, input fingerprint, template version, scope, stale state and canonical hash. The validator also checks symbol, relationship, control-flow and evidence references and source ranges. A changed expected fingerprint rejects a stale bundle.',
'Hashes detect changed artifacts relative to their checksum index. They are not a digital signature proving the identity of an untrusted bundle author. Keep a trusted copy of the source fingerprint and export identity. Redaction recognizes common credential assignments, access keys, tokens and private keys; explicit exclusions and a disclosure review remain necessary for sensitive projects.',
'Keep the dphdb database together with its managed dphdb.views folder. The database is the authority for authored knowledge; generated manuals and diagrams are derived outputs. At the owner\'s direction, D: development backups are suspended until explicitly resumed. Validated changes are still committed and pushed to both configured GitHub repositories.'
]),
('Troubleshoot common states', [
'PARTIAL analysis: read diagnostics and source availability. Unavailable framework units and unsupported syntax remain visible gaps. Do not clear the label by treating unresolved facts as verified. Source changed during analysis: allow reassessment or invoke Full reassessment after the source settles.',
'Cached artifact missing or damaged: retain the database and its previous backups, then attach the correct source to rebuild a derived workspace. Different source root: DPH rejects cross-project reuse; relocation must preserve and verify project identity rather than attach an unrelated project. Knowledge changed since loading: refresh and review the current immutable revision before saving.',
'Embedded preview unavailable: inspect index.html in the exported folder and check the deployed Microsoft loader and WebView2 Runtime. No named author or reviewer: enter an attributable name. Closing waits for background work: cancellation is checked at safe stage boundaries; a long parser stage does not execute the analyzed program.'
]),
('Practice a maintenance handoff', [
'Locate startup from the selected project inventory. Find the main form and a visible action, follow its serialized event to the handler, inspect callbacks and downstream calls, and distinguish certain edges from inferred ones. Locate a dry-run branch or another configuration-dependent path, then identify the model used to produce a report.',
'Record what the evidence establishes and what remains unknown. Add an attributed author answer for missing business rationale, reassess a controlled source change, and verify that the explanation remains pending review. Export a focused task bundle and validate its hashes. This scripted practice supports onboarding; it does not replace the required independent first-time programmer acceptance exercise.'
])]

ENGINEERING = [
('Architecture and boundaries', [
'DPH is an independent Delphi FMX application. It has no converter runtime or build dependency. The pinned VCL2FMXConverter v6.0.0 corpus is test input only, at commit e1fd10b2d3b06f2fc3f726b8eb7f234a54faf63d. No converter source was copied into the current analyzer. Preserve the original planning documents and global agents.md byte for byte.',
'The pipeline is selected project, bounded inventory, read-only byte acquisition, lexical and conditional processing, Pascal and form IR, semantic relationships and control flow, revision-consistent SQLite capture, cached workspace projection, curated knowledge and derived publication. Contract data remains separate from FMX. Every unsupported construct or unavailable dependency must remain diagnosable rather than being promoted into false completeness.',
'All application controls are serialized in DPH.UI.Main.fmx and editable in the IDE. List contents and paint-box geometry are data projections. No scanned component class is instantiated. Avoid adding runtime-only controls, Pascal class helpers or an alternative authoritative store without explicit authorization.'
]),
('Rework and acceptance status', [
'The owner rejected the earlier WP7 delivery as inadequate for learning and handoff. The statement that implementation through WP7 was complete has been withdrawn. docs/Rework_Requirements_Audit.txt compares the original plan with the implemented product and outstanding work. Historical WP reports remain historical evidence, not acceptance of the reworked experience.',
'The rework adds a first-launch Getting started course, deterministic explanation engine, guided learning workspace, source-comment context, event traces, labeled and collapsed procedure-flow views, attributed screenshot imports and richer project-specific publication. Run tools/build-learning.cmd with an optional pinned reference database path for dedicated learning and real-WebView2 tests. The source-based first-time-programmer exercise still needs a human participant.',
'Affected-only semantic recomputation, broader external-definition interpretation and retention/continuity controls remain incomplete. Source safety, privacy, attribution and exact generation links are retained. Do not turn an automated pass count into a claim that every requirement or the human onboarding goal is finished.'
]),
('Build and deployment', [
'The installed compiler is RAD Studio 37.0.59082.6021. Load C:\\Program Files (x86)\\Embarcadero\\Studio\\37.0\\bin\\rsvars.bat before compiling. tools/build-wp0.cmd builds DelphiProjectHandoff.dproj with elevated MSBuild and runs the FMX resource smoke test. Output is bin/Win32/Debug, with DCUs in dcu/Win32/Debug. The initial executable target is Windows Win32.',
'Deploy the executable, migrations 001_foundation.sql and 002_constraints.sql, and the architecture-matched WebView2Loader.dll. The reviewed Microsoft WebView2 SDK package is pinned to 1.0.4258.31; retain tools/WebView2/LICENSE.txt with binary redistribution. The browser loads the DLL by its absolute executable-folder path and activates Edge only when preview is requested. There is no intended IE fallback.',
'The repository standard folders include bin, dcu, docs/guides, docs/pdf, export, help, images and icons, samples, source distributions and tools. Deploy help/index.html for first-launch education. Reference source and generated test databases remain ignored. Use the explicitly approved Python 3.13 executable for project tooling and the installed LibreOffice, never Microsoft Word.'
]),
('Input acquisition and project scope', [
'DPH.Project.Inventory follows the selected project, explicit references, uses clauses, include paths and approved external roots. Project XML is passive: targets and imported build scripts are not executed. Canonical paths are project relative and normalized; traversal, ambiguous macros, reparse paths, cycles and oversized acquisition are rejected or diagnosed. A repository-wide count of Pascal files is not the build scope.',
'DPH.Project.Source opens input read only, checks the final opened Windows handle path, captures bytes, records SHA256 and verifies decoding by round trip. Unicode byte offsets, line endings and explicit legacy encodings remain in the evidence contract. The maximum acquired source is 16 MiB. Binary forms are parsed as data; unsupported resources remain gaps.',
'A source viewer must re-acquire the live file and match the captured hash before using a cached range. Externally referenced sources use their explicit canonical inventory identity. Never invent a neighboring source path from a cached filename or execute input to fill an analysis gap.'
]),
('Syntax contracts and limits', [
'DPH.Parse.Model defines IR schema 1, analyzer DPH-WP2-1, token and node limits, source ranges and diagnostics. Lexing preserves original tokens and conditional information. Preprocessing evaluates supported expressions, explicit defines and includes while retaining uncertainty for unknown branches. An unavailable compiler symbol is not automatically a false condition.',
'The Pascal parser extracts declarations, routines, anonymous methods and supported statements into IR. Declaration and implementation occurrences remain distinguishable before semantic unification. The form parser accepts supported text and binary DFM/FMX structures without loading component packages. The inventory reads relevant project configuration and resources through bounded adapters.',
'Current bounds include 250000 tokens, 100000 IR nodes, nesting 128 and 10000 diagnostics. Opaque assembler, malformed syntax and unsupported grammar are partial. Tests use exact golden IR, encoding edge cases, cyclic includes, passive malicious imports and changed source. Maintain source byte ranges and diagnostics when extending support.'
]),
('Symbols and typed relationships', [
'DPH.Analysis.Model defines semantic schema 1 and analyzer DPH-WP3-1. Stable symbol keys contain qualified identity, signature and conditional variant. DPH.Analysis.Symbols unifies supported routine prototypes and bodies, resolves cross-unit declarations, typed receivers and suitable overloads, associates form events and records anonymous callbacks.',
'Relationship certainty is confirmed_static, possible_dynamic, inferred, runtime_observed or unresolved. Passive scanning never claims runtime_observed. A uses dependency is not a call. Known lexical calls, serialized bindings and declared types carry derivation rules and source ranges. Recognized asynchronous API spelling can establish a possible scheduling relationship without proving execution order.',
'Method pointers, unresolved receivers, dynamic dispatch, generated types and framework behavior must retain uncertainty. Basic reads, writes, callback assignment, static SQL spelling and report-model rendering are conservative analyses. Renames are distinct identities until continuity is reviewed; offsets alone must not reassign knowledge.'
]),
('Control flow and impact', [
'DPH.Analysis.Flow builds per-routine control-flow nodes and typed edges for supported sequences, branches, loops, returns and exception/finally paths. Routine identity, source hash, range, node kind and expression remain available to inspectors and exports. Flow is bounded to 100000 nodes, 300000 edges and nesting 128.',
'Impact traversal is possible reachability through supported relationships. Do not label it proved runtime impact. The UI bounds a displayed graph to 120 nodes and 960 edges, while the stored semantic graph is the fuller evidence model. Uncertain edges remain visually distinct. Unsupported flow does not become a fabricated successful path.'
]),
('SQLite generations and durability', [
'TDPHKnowledgeStore owns one FireDAC SQLite connection on its creating thread and serializes writer access through a named mutex. Foreign keys and synchronous FULL are enabled. Default journal mode is DELETE; WAL is an explicit local-store option. Direct cross-thread writes are rejected. SQLite 3.42.0 with FTS5 was measured by the storage tests.',
'Schema 2 is created through two checksum-verified migrations. Existing migration text is immutable. A newer incompatible schema is rejected safely. Failed upgrade DDL and ledger changes roll back, and an upgrade from an existing schema makes a recoverable pre-migration database backup. Interrupted running generations recover as failed, preserving the previous published head.',
'ObserveManifest records current fingerprints independently of the capture. BeginGeneration freezes configuration and manifest identity. Syntax and semantic facts are staged in transactions. Before publication, inputs and configuration are revalidated. Only a coherent complete generation becomes the current head. Partial, failed or superseded captures cannot clear the exact-input stale state or overwrite a prior current head.'
]),
('Evidence and immutable history', [
'Normalized tables include projects, configurations, source files, file revisions, generations, generation files, entities, entity versions, evidence, relationships, component properties, control-flow nodes and edges, knowledge records and revisions, links, review tasks, translations, artifacts, export jobs and audit events. Foreign keys tie evidence and relationships to their producing generation.',
'Triggers prevent mutation of terminal generations, source revisions, captured facts, configurations and authored knowledge revisions. Evidence ranges must fit the captured source bytes and use the generation analyzer version. Historical file and entity identities cannot be changed casually. A missing source is retained as missing; its historical annotations survive.',
'Modification detected, analysis stale, knowledge review needed, analysis failed and reassessment requested are separate persistent flags. A UI summary is a projection of these states, not a replacement for them. Parser success must not clear human review.'
]),
('Background coordination and cached views', [
'DPH.Workspace.Worker is a persistent TThread with bounded request and response queues. It initializes COM for passive MSXML parsing, owns database operations in the worker, and retains analyzer instances across requests. FMX polls responses with a timer, avoiding queued closures that outlive the form.',
'A stopped Delphi queue can report success while returning an empty item. Poll checks both the wait result and a non-nil response; shutdown tests guard against a destructor loop. Cancellation is checked between stages and marks a staged running generation failed when appropriate. It is not a promise of interruption inside every parser loop.',
'Workspace projections are managed JSON files in database.dphdb.views named by SHA256 and registered in artifacts. Cached opening verifies the managed path, size, checksum and generation. The default is detached until explicit source attachment. Connected checks compare manifest fingerprints and selection identity every ten seconds. Syntax cache reuse is bounded; semantic recomputation is currently conservative rather than a claim of a minimal incremental semantic solver.'
]),
('FMX navigation and visualization', [
'DPH.UI.Main binds its published controls to the FMX resource. Explorer queries are paged at 250 rows; data filtering supports kind, text and qualified scope. History and bookmarks use canonical keys, with bookmarks reset on a new captured generation. Inspector output retains source metadata and serialized properties. Source memo navigation is permitted only after live hash validation.',
'OpenSelection queues a candidate without replacing the current database, source or workspace. PollTimer installs it only after the worker returns accepted captured evidence. The worker preflights source identity before creating a database; cached opens check captured XML ProjectGuid and Pascal program declarations before returning a view. Rejections retain the current workspace, and rejected startup caches show Getting started. Inventory identity also covers referenced project groups. DatabaseDialog.InitialDir is the design-time relative default; startup resolves it under the deployment root, creates that folder, and applies the same path to OpenCacheDialog. Distribution packaging copies only the Databases instructions, never its databases or views.',
'Graph paint boxes draw bounded evidence data with palette and geometry values supplied by design-time style rectangles. Screen reconstruction draws approximate source-derived rectangles without creating components. Its gallery is bounded to 60 forms. Runtime styles, custom painting and inherited resources are not silently fabricated.',
'Keep lifecycle and ownership explicit: the view owns its JSON document, UI arrays own their records, responses transfer document or knowledge ownership to the main form, and the worker frees unconsumed responses during shutdown. Guard unsaved authored text before changing projects or replacing editor state.'
]),
('Curated knowledge and review', [
'SaveKnowledge requires title, body, a named author, a supported kind and a captured generation. Existing records require their expected revision and stable title/kind. Each edit appends a needs_review revision, preserves links and opens a pending task. Knowledge bodies are bounded to 1 MiB. Authored text is never regenerated from parser output.',
'ReviewKnowledge requires the expected current revision, a named reviewer and a matching captured source/configuration. The connected worker observes current source before accepting a review. A missing linked entity cannot be verified under a replacement name. Verification, rejection or retirement appends a revision and records attribution; history remains append only.',
'Manifest and configuration changes conservatively invalidate active knowledge, derived artifacts and translations. A partial static capture may support review of an attributable statement against available evidence, but its partial coverage remains visible. Local names are not authenticated enterprise identities. Human verification and automatic static derivation remain different evidence categories.'
]),
('Canonical publication and privacy', [
'DPH.Publish.Model constructs one versioned documentation model from a captured workspace and current curated knowledge. It carries generation, configuration, input/context fingerprints, detached/stale state, symbols, typed relationships, control flow, source references, human history, coverage and explicit unknowns. Full and task-scoped views share those facts.',
'Task scope selects the requested identities and complete direct incident context. It rejects missing or excluded seeds and rejects an oversized task rather than silently truncating a full export. External source roots and sensitive filename categories are excluded by default. Explicit relative prefix exclusions remove file-derived symbols and relationships. Source snapshots and generated AGENTS.md are absent by default.',
'Redaction recognizes common credential assignments, private keys, AWS access keys and JWT-shaped tokens throughout string data. It is defense in depth, not a guarantee that every project-specific secret format is recognizable. Require explicit exclusions and a disclosure review for sensitive content. No translation or AI provider is contacted by normal publishing.'
]),
('HTML guides and bundle validation', [
'DPH.Publish.Export writes a new destination outside source. The offline HTML uses encoded imported text, local search and styles, internal anchors, print CSS and a restrictive content security policy. The default WebView2 policy permits only the authorized local index and about:blank; publication explicitly enables hash-named object pages in its managed objects folder. Learning and help retain the index-only policy. There is no arbitrary native bridge. Data does not supply executable markup.',
'JSONL indexes contain symbols, relationships, forms/events, data usage, configuration, flow nodes, knowledge and evidence references. Manifest and checksum files accompany canonical.json. The validator checks filenames, hashes, expected input fingerprint, canonical identity, source hash/range, generation and cross-reference integrity. A stale manifest is rejected by default. Unsigned hashes establish integrity relative to the index, not author authenticity.',
'Editable engineering and user DOCX guides derive from the same sections and evidence model. They include title, last changed capture identity and a changeable TOC field. LibreOffice provides companion PDFs; the project rendering tool verifies cached page numbers and renders page images for layout inspection. Missing business procedures stay explicitly absent rather than being invented.'
]),
('Translation boundary', [
'IDPHTranslationProvider exposes provider identity, version, external status and prose translation. Protected segments retain identifiers, SQL, paths, hashes and protocol keys byte for byte. Cache keys include source content, revision, source/target locales and provider/version. Changed prose produces a fresh pending entry; named review applies to the exact cached translation.',
'TDPHAtlasAdapter is deliberately unconfigured because the exact Atlas product, transport, licensing and confidentiality have not been selected. External providers require explicit consent. The current adapter throws before transmission, and tests use an offline mock. The offline GTranslate region is disabled, with local bilingual labels and sorting; do not activate network translation merely because a generic widget name appears in documentation.'
]),
('Verification and release discipline', [
'Run the phase build/test scripts elevated with the installed toolchain. WP0 checks FMX resource ownership; WP1 checks storage, crash recovery and migrations; WP2 checks inventory, encoding, syntax and source safety; WP3 checks semantics and pinned reference traces; WP4 checks workspace/background behavior; WP5 checks immutable authored history and pending review; WP6 checks publication, exclusions, sanitization, hashes and translation protection.',
'Use exact input hashes before and after analysis, including failures. Preserve original reference and instruction files. Keep tests that demonstrate invariants rather than tests that merely mirror implementation. New source, validation failure or unresolved risk justifies another targeted test; a passing unchanged phase does not need endless repetition.',
'D: development backups are suspended at the owner\'s direction until explicitly resumed. Git remains enabled: review intended changes, commit validated work and push both public and private remotes without force or history rewriting. Remove a stale zero-byte index lock only after verifying no Git process runs. WP7 records measured performance, portability, security and explicit acceptance evidence. Independent first-time programmer acceptance and unknown historical business intent cannot be invented by automation.',
'On the recorded Core i7-1165G7 host with eight logical processors and about 16 GB RAM, the pinned reference pipeline measured 82.6 seconds for full capture, 2.87 seconds for cached opening and 75.9 seconds for incremental reassessment. The message-pump maximum gap was 64 ms. Peak test-process working set was about 1.21 GiB, including repeated captures, JSON cloning and FMX/WebView2 tests. These are baseline measurements, not agreed hardware-independent budgets. Large syntax-cache fallback and conservative semantic recomputation explain the modest reassessment speedup. Formal acceptance retains independent complex-flow review, missing business/user content, AC-25 and performance-budget agreement as outstanding.'
])]

# Keep the operating instructions aligned with the design-time controls and
# persistence contracts. These chapters describe behavior, not inferred intent.
USER.extend([
('Manage the project catalog', [
'Choose Projects in the page selector at the upper right. Refresh the catalog, select the intended database and open it. Missing entries identify unavailable paths; they do not mean the project or its authored history was deleted. Remove an entry only when you want to remove that catalog reference. Catalog removal does not delete the database or managed evidence.',
'Use one database per analyzed application. Keep its adjacent .views directory with it. A database is not the source project: DPH can inspect cached facts when the source is unavailable, but current-source review and source navigation require attached matching source. When the original entry is available, cached opening displays captured facts first and then verifies that source in the background.'
]),
('Measure coverage before relying on an explanation', [
'Choose Coverage in the page selector. Read each numerator, denominator and definition separately. Fingerprinted inventory measures acquired inputs; parsed files, complete IR and recognized tokens measure supported parsing. Confirmed and unresolved relationships measure the extracted graph. Serialized event coverage applies to captured On-prefixed properties. Evidence coverage applies to source-located relationships with derivation rules.',
'Select a diagnostic and inspect its source evidence. A missing unit, ambiguous overload or unsupported construct can change what a route means. None of these percentages measures business understanding. Verified authored revisions and pending review tasks are reported separately; a zero task count is not proof that all necessary documentation exists.',
'The selected application is not built or tested merely because DPH finished analysis. Read explicit unknown build and documentation approval states before sharing a handoff. Record the actual independent test procedure and result as attributed knowledge.'
]),
('Search across the captured project', [
'Choose Project search. Enter a meaningful term, select the desired kind filter and click Search. Results contain excerpts from captured object metadata, flow evidence and authored knowledge. Select a result to inspect it; use next or previous result pages when offered. This search is distinct from the narrower Explorer name and signature filter.',
'Search uses SQLite FTS5 when available and a word-index fallback otherwise. It operates on the captured generation. A word absent from the index is not evidence that its behavior is absent. Reassess changed source before relying on old results.'
]),
('Read a routine as a beginner', [
'Select a routine in Explorer and choose Explain. Read its declared contract, source-author comments, incoming callers and outgoing interactions. Expand the exact-evidence disclosure for a connection you do not understand. A comment records what its source author wrote; it does not independently establish the running behavior.',
'Scroll to SOURCE WALKTHROUGH. Each source point includes the captured expression, a plain explanation and possible next paths with destination lines. For an if, inspect both true and false destinations. For while, inspect the condition before the body. For repeat, the body runs before its final test, and false returns toward the body. For for, inspect the iteration and exit paths without assuming actual bounds or collection contents.',
'Follow early return, break and continue through any intervening finally cleanup. Cleanup points may appear several times to preserve different pending transfers. An exception path represents a possibility; it does not establish that a particular run raised an exception. The walkthrough is arranged by source location and is not a chronological execution recording.',
'Complete CHECK YOUR UNDERSTANDING by choosing an actual captured condition and tracing both outcomes to a return, loop or exception boundary. Compare the related reads and writes. The lesson shows up to 60 source points and eight next paths per point, with explicit omitted counts. Use Source and Procedure CFG for the remainder.'
]),
('Choose graph scope and grouping', [
'Choose Graphs after selecting an object. Execution follows supported startup, event, call and asynchronous connections; Caller / callee isolates calls; Form navigation shows qualified form actions; Data flow shows producers, consumers and possible effects; Change impact follows possible dependencies. Procedure CFG follows captured statement edges within a routine.',
'Use Whole program, All forms or Project data when you need a broad starting point. Choose object, type or unit grouping to reduce a large relationship graph. Select a group to inspect its members and bounded evidence examples. A count describes the captured projection; it does not count observed executions. Procedure CFG retains individual control nodes.',
'Read arrow labels and certainty before interpreting a route. A unit import is a dependency, not a call. An asynchronous start, callback dispatch, wait or cancellation request describes a source site; it does not prove successful completion, thread timing or termination. Narrow a truncated graph rather than treating missing nodes as proof of absence.'
]),
('Link authored sections to exact evidence', [
'In Knowledge, select the document kind and intended audience before saving. The section ID and revision label identify the stable record and immutable revision. Editing creates a new pending revision; it does not overwrite a previously reviewed statement.',
'Choose Knowledge links. Select entity, relationship, evidence, screenshot or section, enter a target filter and refresh candidates. Select the intended target and the role explains, cites, depends_on or illustrates. Add the link, then return to Knowledge and click Save. Removing a link is also an unsaved edit until Save. A section can contain up to 64 explicit links.',
'Open a saved target to inspect its object explanation, normalized relationship or evidence details, imported PNG, or exact historical section body. A section link pins a particular revision. If its target is updated, explicitly relink and save after reviewing the new content. DPH does not silently transfer your approval to a newer target.',
'Export applies audience and source scope. Out-of-scope links and backlinks are omitted with counts. An audience filter is a document organization choice; it is not a confidentiality boundary. Use explicit exclusions and inspect the resulting bundle before disclosure.'
]),
('Review changed knowledge against evidence', [
'Choose Review tasks and refresh. Select a task to read its original trigger, prior authored text and current revision. Compare the BEFORE and AFTER panes for source presence, signature, type, hash and configuration. Drag their divider to resize them. An unavailable baseline is explicitly missing, not reconstructed from guesses.',
'Select an affected object and inspect Change impact or open its knowledge record. Save an authored correction before returning to task review. Enter the named reviewer and choose Verify selected only after checking the exact current content. Choose Retire selected for an obsolete section whose history must be retained.',
'Review requires attached current-source verification and the expected revision. A changed configuration, source hash, absent entity or obsolete rich-link target can reject approval. Resolve the underlying mismatch, refresh, and review again. Review changes the authored record state; it does not make a partial analyzer capture complete.'
]),
('Answer focused author questions', [
'Choose Author questions. DPH derives bounded questions from uncertain relationships, diagnostics, asynchronous work, SQL and output contracts, and missing reviewed user or build procedures. Select a question and inspect its evidence before contacting its author. Up to 100 questions are shown, with at most 20 per category.',
'Choose Record author answer. In Knowledge, enter the named author and their actual response after the Answer marker, then Save. An empty answer is rejected. The captured question remains associated with that record. Saving leaves it pending review; only named verification with no pending task hides that exact question.',
'Changed evidence can produce another question or reopen review. Similar wording does not establish identical evidence. Do not invent business rationale, runtime outcomes or operating procedures just to clear the list.'
]),
('Preserve saved runtime observations', [
'Select an optional object link in Explorer, then choose Runtime observations. Enter Contributor and Run, environment and outcome description. Include the actual application build, run date, platform, action, expected result and observed result. Click Select saved log and import, then choose an existing UTF-8 .txt, .log or .json extract up to 256 KiB.',
'Select the record to read its attribution, captured generation, linked source SHA256, original-file SHA256 and saved text. The text is displayed literally. File order and timestamps remain contributor claims; DPH did not run the application or infer causal order. Invalid UTF-8, empty extracts and damaged managed files are rejected.',
'Use Explain linked current object to investigate a current-generation link. Historical and unlinked records retain their text without assuming a current identity. After reopening the database, choose Refresh saved records. The newest 50 are displayed. Managed portable backups include observations; publication does not automatically share log contents.'
]),
('Retain captures and review rename continuity', [
'Choose Database tools. Preview the retention policy before applying the desired recent-capture count. Pin an important generation with a release label and named reviewer before pruning disposable cached views. Baseline, current head, recent captures and generations referenced by review or contributed evidence are protected.',
'Retention removes eligible derived workspace files; immutable source facts and authored history remain. It is not a command to erase the project database. Keep a recoverable copy using the explicit backup workflow before a major catalog or storage operation when needed.',
'If a linked object disappeared after a rename, open the continuity workflow, filter proposals and compare old and new identities. Enter a named reviewer before approving a justified mapping. Approval preserves historical links, appends an authored revision and requests review. It does not prove semantic equivalence from name similarity.'
]),
('Back up and restore a complete database', [
'Choose Database tools and run Integrity. Read the result before relying on the database. For an explicit portable backup, choose a new .dphdb destination outside the analyzed source. The command saves a consistent SQLite copy, referenced managed views, screenshots and observations, and a SHA256 backup manifest.',
'Keep the backup database and its adjacent .views folder together. Choose Restore to new database and provide a fresh destination. DPH verifies filenames, manifest hashes, database integrity and managed artifacts, and refuses to overwrite an existing database. Open the restored copy and confirm the intended project, generation and authored history.',
'The suspended D: development-backup instruction remains in effect. Explicit database backups requested through this workflow are separate operations. Git continues to preserve application source changes.'
]),
('Run the application and its checks', [
'To run the current source build, open C:\\New Delphi Projects\\Delphi Project Handoff\\bin\\Win32\\Debug in File Explorer. Double-click DelphiProjectHandoff.exe. Keep the deployed migrations and help folders and the Win32 WebView2Loader.dll supplied by the build beside the executable. Select a different Delphi application to analyze; DPH rejects itself.',
'For a first check, choose the intended Debug or Release and Win32 or Win64 analysis configuration, then Attach project. Save its database outside that selected source. Wait for the activity line to finish, select a recognizable form event, and follow its handler through Explain, Source and Graphs. Read Coverage before drawing conclusions. Close and reopen its saved database and confirm the same captured identity and notes.',
'For developer regression checks, open an elevated Command Prompt, run cd /d "C:\\New Delphi Projects\\Delphi Project Handoff", then run tools\\validate-completion-wp1.cmd. A nonzero exit or FAIL is a failure. Run tools\\build-learning.cmd for source lessons and real WebView2 checks, tools\\build-wp1.cmd for storage and migrations, and tools\\build-wp6.cmd for publishing. These tests create disposable fixtures, not user projects.',
'Automated checks cannot substitute for an independent beginner explaining an actual program. Record the participant, project, chosen event, identified branches and effects, unresolved questions and outcome. Do not mark the first-time-user acceptance gate passed without that evidence.'
])])

ENGINEERING.extend([
('Current semantic cache and extended evidence', [
'The current analyzers are DPH-WP2-5 and DPH-WP3-11 with IR and semantic schema 1. Routine semantic cache reuse is bounded to 512 records and 32 MiB. Binding context hashes invalidate affected reuse. Synthetic startup and postprocessing occur after reusable routine facts, preserving their relationships to current identities. This is bounded evidence reuse; it is not a proof of an optimal incremental solver.',
'Supported extensions include typed aliases, inheritance and accessors, startup entry and unit phases, case/goto/with control flow, asynchronous operation handles and captures, cancellation and event waits, formal arguments and result producers, static SQL projection, output-writer lineage, lifetime and exception relationships, explicit test-call links, and qualified form navigation. Every relationship retains resolution, source range/hash and rule. Unsupported grammar, aliases and dynamic behavior remain diagnosed or qualified.'
]),
('Current schema and authored document contracts', [
'Schema 8 uses checksum-verified migrations 001 through 008. document_section_versions associates immutable authored revisions with stable section ID, document kind, audience and source generation. knowledge_revision_links preserves ordinal, target kind/identity, captured generation, role and label. knowledge_questions preserves the exact deterministic question identity and captured JSON associated with a response record.',
'SaveKnowledge appends immutable text and link snapshots. Empty LinksJSON preserves the prior snapshot; an explicit JSON array replaces it. Entity, relationship and evidence targets remain tied to generation identities; screenshot targets reference managed artifacts; section targets pin an exact knowledge revision. Current reverse section references open review when their targets change. Verify rejects obsolete rich-link generations or target revisions.',
'Question identity hashes kind, entity key, range, source hash, prompt, rule and context fingerprint. Generation is retained separately, allowing unchanged evidence to keep its question identity across captures. An answer needs actual text after Answer. Only verified content with no pending task suppresses an exact question. Export converts question metadata to typed JSON before recursive redaction.'
]),
('Native review and learning projections', [
'ReviewTasks provides bounded pending tasks, prior and current authored text, baseline/current configurations, affected object signatures, types, source hashes and relationship comparisons. A missing baseline is reported. Native controls invoke existing optimistic-revision and connected-source review checks; they do not create a separate approval authority.',
'RoutineLesson uses the routine CFG and an indexed outgoing-edge lookup. It explains source points, actual expressions and destination lines, with explicit loop, branch, early-return, cleanup and exceptional semantics. The same lesson is used by ObjectText and ObjectHTML; exported document prose and offline object pages therefore share its source interpretation. Its bounds are 60 points and eight outgoing paths per point.',
'Preview HTML files have immutable content-hashed names, tracked for cleanup. BrowserPolicy allows them only in the owned preview directory when explicitly enabled. This avoids rewriting a file held by WebView2. Arbitrary filenames and external navigation remain blocked. Native browser tests render the app pages; they do not execute the analyzed application.'
]),
('Saved observation persistence', [
'ImportObservation accepts explicitly selected UTF-8 text extracts up to 256 KiB with named contributor and run context. It checks generation and optional entity existence, captures original byte SHA256 and linked file-revision SHA256, and stores content plus attribution in a managed hash-named JSON artifact of kind runtime_observation. No schema migration is needed for this artifact kind.',
'ObservationsJSON verifies managed identity, size, checksum and generation before returning the newest 50 records. The response owns the array until PollTimer transfers it to the form. LoadView clears old observation rows; historical records cannot navigate as current. Saved text stays in a native read-only memo rather than an executable browser surface.',
'ManagedArtifactPaths includes observations for explicit portable backup. Retention protects their associated captured views. Publication currently omits observations rather than automatically disclose potentially sensitive logs. Contributor claims do not set runtime_observed on static analysis or create an automated causal trace.'
]),
('Regression commands and evidence', [
'Run commands from the project root in an elevated Command Prompt so RAD Studio can read its environment. tools\\build-wp0.cmd builds the app and checks FMX bindings. tools\\validate-completion-wp1.cmd serially builds app, catalog, lifecycle, workspace, knowledge, selection and startup tests, then removes recognized disposable fixture directories.',
'Run tools\\build-wp1.cmd for 46 storage checks, tools\\build-wp2.cmd no-report for discovery/resource checks, and tools\\build-wp3.cmd to compile semantic tests. Then explicitly run bin\\Win32\\Debug\\DPH.Tests.Semantics.exe "C:\\New Delphi Projects\\Delphi Project Handoff"; the build script alone does not run semantic assertions.',
'tools\\build-learning.cmd exercises managed images, cached supplemental-evidence recovery, actual WebView2 rendering, source walkthroughs and collapsed CFGs. --no-ui isolates deterministic checks and is not native acceptance. tools\\build-wp6.cmd checks canonical scope, redaction, link integrity, publication and translation protection. Use exact log files and current input hashes for claims; historical reports are not automatically refreshed acceptance.',
'A native-learning test once dereferenced an absent image array on a later background-verification response. It now checks the initial cached document/image response directly. Source attachment preserves supplemental-image warnings. Inspection disproved a proposed constructor race, and no worker thread-start change remains.'
]),
('Rebuild and inspect these manuals', [
'tools\\build-guides.py generates the two application manuals from maintained operating content and current implementation hashes. Use the approved Python executable C:\\Users\\marti\\AppData\\Local\\Microsoft\\WindowsApps\\python.exe. tools\\render-guides.ps1 renders with LibreOffice, populates cached page numbers in editable TOC fields, renders again and writes companion PDFs under docs\\pdf.',
'Inspect every final page PNG under bin\\guide-qa for clipping, broken headings, unreadable code and TOC page numbers before delivering a guide. Rendered PNGs are QA outputs, not a mock application UI. Actual included interface images are identified by their capture source and fixture; they do not establish runtime behavior of a selected project.',
'Regenerate manuals after later translation, handoff-contract or source-navigation changes. The source evidence appendix records inspected file hashes, while docs\\guide-source-validation.json provides a machine-readable manifest. A successful generator run alone is not proof that the writing, current behavior or layout is correct.'
])])

# Correct historical statements in the original guide text instead of leaving
# contradictory behavior beside the new chapters.
revisions = {
    'Choose Project search.': 'Choose Search project in the upper-right page selector.',
    'click the central Explain tab for behavior or Source for code.': 'choose Explain in the upper-right page selector for behavior or Source for code.',
    'Click the central Explain tab for behavior or Source for code.': 'Choose Explain in the upper-right page selector for behavior or Source for code.',
    'click the Learn the project tab in the centre': 'choose Learn the project in the upper-right page selector',
    'Open the central Explain tab': 'Choose Explain in the upper-right page selector',
    'Learning and help retain the index-only policy.': 'Help retains the index-only policy; learning explicitly permits content-hashed pages only inside its owned preview directory.',
    'Double-click an object in the far-left list to read': 'Click an object in the far-left list to read',
    'Double-click an Explorer object or follow a learning link': 'Click an Explorer object or follow a learning link',
    'Double-click an object in the far-left Explorer list to select it.': 'Click an object in the far-left Explorer list to select it. Double-click a [+] or [-] branch to expand or collapse its children.',
    'the local user profile and reopens detached.': 'the local user profile; reopening shows cached facts before source availability is checked.',
    'use next or previous result pages when offered.': 'use Next 50 results when more matches are available.',
    'run Integrity.': 'click Check integrity.',
    'choose Restore to new database': 'choose Restore to new file',
    'Choose Restore to new database': 'Choose Restore to new file',
    'Cached opening does not start a source scan. The cache opens detached until you explicitly attach its source project.': 'Cached facts are displayed before source verification. When the captured entry is available, DPH reconnects and verifies in the background; otherwise the cache remains detached.',
    'Bookmarks belong to the captured generation and reset when a new generation is loaded.': 'Same-project reassessment retains surviving bookmarks, history, expanded nodes and filters; missing identities are pruned. A different project resets that navigation state.',
    'Zoom displays 200 percent, and Full screen uses the larger window. The Full screen button toggles the DPH window size.': 'Custom zoom ranges from 25 to 400 percent and updates the scrolling extent. Full screen hides the surrounding workspace panes; Exit full screen or Escape restores them.',
    'Deploy the executable, migrations 001_foundation.sql and 002_constraints.sql,': 'Deploy the executable, all eight immutable migration files,',
    'analyzer DPH-WP2-1': 'analyzer DPH-WP2-5',
    'analyzer DPH-WP3-1.': 'analyzer DPH-WP3-11.',
    'Schema 2 is created through two checksum-verified migrations.': 'Schema 8 is created through eight checksum-verified migrations.',
    'The default is detached until explicit source attachment.': 'Cached facts are delivered before automatic verification when the original source entry is available; unavailable source remains detached.',
    'Syntax cache reuse is bounded; semantic recomputation is currently conservative rather than a claim of a minimal incremental semantic solver.': 'Syntax and routine semantic caches are bounded and binding-context aware; conservative postprocessing remains separate from reused routine facts.',
    'with bookmarks reset on a new captured generation.': 'with surviving same-project bookmarks retained across reassessment.',
    'Affected-only semantic recomputation, broader external-definition interpretation and retention/continuity controls remain incomplete.': 'The implementation tracker records expanded semantic reuse, resource interpretation and retention/continuity controls. Their documented bounds still apply.',
    'Atlas is unconfigured.': 'Atlas uses independently vendored DAT offline language packs; no complete DPH language catalog is supplied.',
    'Generated AGENTS.md and source snapshots are excluded unless a separate explicit request is implemented and authorized.': 'Generated AGENTS.md and redacted source browsing are separate unchecked options described below. Original source bytes are never copied.',
    'On the recorded Core i7-1165G7 host': 'In the historical pre-rework benchmark on the recorded Core i7-1165G7 host',
    'TDPHAtlasAdapter is deliberately unconfigured because the exact Atlas product, transport, licensing and confidentiality have not been selected. External providers require explicit consent. The current adapter throws before transmission, and tests use an offline mock.': 'TDPHAtlasAdapter reads explicitly selected DAT JSON packs offline. The independent Apache-2.0 reader snapshot and license reside under dependencies\\DelphiAppTranslation; VCL2FMX is unchanged and is not a build or runtime dependency. No network provider is configured. Tests exercise actual packs, persistent cache, terminology changes, source invalidation and exact-content named review.',
}
for chapters in (USER, ENGINEERING):
    for index, (heading, paragraphs) in enumerate(chapters):
        for old, new in revisions.items():
            paragraphs = [paragraph.replace(old, new) for paragraph in paragraphs]
        chapters[index] = (heading, paragraphs)

USER.extend([
('Translate and review saved sections', [
'Choose Translations in the upper-right page selector. First select a saved Knowledge revision. Enter the source locale and requested target locale, for example en and fr. Click the language-pack selection command and select an explicitly supplied DAT JSON pack. DPH requires its applicationId to be DelphiProjectHandoff. A matching base pack may serve a regional request; the requested and actual locales are both displayed.',
'Compare the labeled source and localized panes. Source phrases absent from the pack remain unchanged with a fallback count. Code, SQL, paths, hashes and protected identifiers retain their original characters. Fence unusual technical material in backticks or code blocks before translation. A terminology JSON object supplies exact prose replacements; changing it creates a newly pending derived result.',
'Review the source section against current attached evidence and resolve its pending tasks before approving a translation. Enter the translation reviewer name and approve only complete, accurate wording. A fallback cannot be approved. Editing source prose or invalidating its source evidence invalidates approval. Translation review does not verify the underlying business explanation.',
'For a small practice only, save the exact body Run conversion and use samples\\translation\\DPH.fr.sample.json. The result is Exécuter la conversion. This pack has only three unreviewed phrases and is not a complete language catalog. Existing entries survive closing and reopening the database.'
]),
('Publish localized text and source browsing', [
'Choose Publish. Leave Localized prose locale blank for normal publication, or enter the exact target locale used for reviewed saved-section translations. Export to a new folder. Open index.html and the localized authored-sections link. Localized_Sections.docx is the editable companion; the optional PDF command converts it when present. Inspect translated and fallback counts before sharing.',
'Only reviewed exact-revision authored section bodies are localized. Titles, generated guidance and technical indexes remain in their source language. Missing, stale, unreviewed or redacted sections retain explicitly labeled source prose. Each localized entry carries its source revision, source generation, requested and actual locales, reviewer and review date.',
'Include redacted source browsing pages is unchecked by default. Check it only when you intend to share captured code. DPH verifies available eligible files against their captured byte hashes and code page; changed or missing source rejects export. Task exports include cited noncontainer line excerpts, mark omitted lines and retain original line anchors. Shared source lines can contain surrounding code.',
'Open Browse captured source files and omissions from index.html, or use an object explanation\'s captured-source link. Binary or undecodable material, private-key material, files over 4 MiB and files over 20000 lines are omitted with reasons. Source browsing derives redacted HTML; it does not copy original source bytes. Review exclusions and output because redaction cannot recognize every sensitive format.',
'Include generated agent boundaries is also unchecked by default. Checking it writes DPH-generated instructions for that captured scope; it never copies the owner\'s AGENTS.md or grants authority to modify or execute a selected project. The bundle includes project summary, architecture, build and test, known risks and decisions narratives with explicit unknowns.'
]),
('Validate a bundle in the application', [
'Choose Validate bundle. An open database is optional. Paste a trusted 64-character captured input fingerprint, or open the trusted database first and click Use opened capture fingerprint. A fingerprint read only from an untrusted bundle cannot establish its origin.',
'Click Select manifest and validate bundle and select manifest.json at the bundle root. Wait for the background result. Read PASS or FAILED and every reported qualification. DPH checks names, hashes, canonical provenance, technical indexes, ranges, source browsing and localization metadata. Integrity does not prove author identity, complete analysis or reviewed operating procedures.',
'Historical or partial bundles are rejected by default. For deliberate qualified inspection, check Allow historical/partial inspection and select the manifest again. A qualified pass remains historical or incomplete; it cannot approve missing knowledge or current-source behavior.'
])])

ENGINEERING.extend([
('Offline translation and localized publication', [
'Migration 008 adds the persistent translation cache key and JSON record. Cache identity covers saved knowledge revision, requested locales, provider pack hash, source segments and terminology. SQL state overlays cached metadata so source invalidation remains authoritative after database reopen. Approval requires current source review, complete translated prose and a named reviewer; it never updates authoritative source text.',
'TDPHAtlasAdapter uses DAT.Runtime.LanguagePack plus its two copied core dependencies, original license and hashed snapshot provenance. Selected packs are bounded to 4 MiB, strictly UTF-8 and application scoped. Exact source phrase lookup and base-language fallback are explicit. Common code, SQL, paths and identifiers are protected during segmentation; unusual unmarked identifiers still need human review.',
'DPH-LEARNING-6 publication writes localization.json and, when a locale is requested, a hashed HTML page and Localized_Sections.docx. Verified exact-revision cache entries are eligible only while the canonical source section is reviewed and has no pending tasks. Redacted source bodies use source fallback. The supplementary document explicitly limits its scope to authored bodies.',
'Source navigation is separately opt-in. Only scoped captured text with matching source hashes is rendered as encoded, redacted HTML. Task masks use captured noncontainer ranges and original line starts. source-navigation.json records included line numbers and omission reasons. Validate checks scope, file identity, line order/counts, generations and disclosure metadata. No original source snapshot is shipped.'
]),
('Native validation and release evidence', [
'The design-time Validate bundle controls dispatch validate_bundle to the worker before a database connection is required. The owner supplies an expected fingerprint independently. Stale rejection is default and historical inspection is an explicit qualification. Native reports distinguish integrity from human approval.',
'The Win32 project enables DCC_LargeAddressAware in its IDE project options. The hardening and learning harnesses use the equivalent PE flag. The expanded pinned corpus exposed an out-of-memory failure after repeated captures and native workspace loading under the former address limit. Keep memory measurements and actual large-corpus validation with this change; the linker flag does not make memory consumption unbounded or establish a release budget.',
'Run tools\\validate-wp7.ps1 elevated for the pinned reference hardening suite and before/after hash proof. It reads the current schema constant rather than an obsolete hardcoded version. The suite measures full capture, cached open, reassessment, message-pump gaps and peak process working set on recorded hardware. Measurements require owner-agreed budgets before release acceptance.',
'The independent first-time programmer and source-review worksheet is docs\\WP7_Maintenance_Exercise.txt. Preserve actual participant answers, source citations, uncertainty judgments, assistance, timings and defects. Do not substitute automated tests or prepared instructions for AC-25 or independent explanation review.'
])])

user_order = [
    'Purpose and evidence', 'Start DPH', 'Run the application and its checks',
    'Attach a source project', 'Open cached work', 'Manage the project catalog',
    'Learn the selected project', 'Measure coverage before relying on an explanation',
    'Explore and search', 'Search across the captured project',
    'Read source and graph evidence', 'Choose graph scope and grouping',
    'Read a routine as a beginner', 'Inspect screens', 'Import actual screenshot evidence',
    'Write attributed knowledge', 'Link authored sections to exact evidence',
    'Review and retire knowledge', 'Review changed knowledge against evidence',
    'Answer focused author questions', 'Preserve saved runtime observations',
    'Retain captures and review rename continuity', 'Back up and restore a complete database',
    'Publish manuals and handoffs', 'Translate and review saved sections',
    'Publish localized text and source browsing', 'Validate a bundle in the application',
    'Validate and preserve exports',
    'Troubleshoot common states', 'Practice a maintenance handoff',
]
if set(user_order) != {heading for heading, _ in USER}:
    raise RuntimeError('User-guide outline does not cover every maintained chapter')
USER.sort(key=lambda chapter: user_order.index(chapter[0]))

def field(run, kind, text=None):
    element = OxmlElement('w:fldChar')
    element.set(qn('w:fldCharType'), kind)
    run._r.append(element)
    if text:
        instruction = OxmlElement('w:instrText')
        instruction.set(qn('xml:space'), 'preserve')
        instruction.text = text
        run._r.append(instruction)

def build(filename, title, audience, sections):
    doc = Document()
    section = doc.sections[0]
    section.top_margin = section.bottom_margin = Inches(.8)
    section.left_margin = section.right_margin = Inches(.85)
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    for name in ['Normal', 'Title', 'Subtitle', 'Heading 1', 'Heading 2']:
        style = doc.styles[name]
        style.font.name = 'Calibri'
        style.font.color.rgb = RGBColor(0, 0, 0)
    for border in list(doc.styles.element.iter(qn('w:pBdr'))):
        border.getparent().remove(border)
    normal = doc.styles['Normal']
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(7)
    normal.paragraph_format.line_spacing = 1.1
    doc.styles['Heading 1'].font.size = Pt(16)
    doc.styles['Heading 1'].paragraph_format.space_before = Pt(15)
    doc.styles['Heading 1'].paragraph_format.keep_with_next = True
    doc.add_paragraph(title, 'Title')
    doc.add_paragraph('Delphi Project Handoff', 'Subtitle')
    doc.add_paragraph('Windows desktop experimental software')
    doc.add_paragraph('Last changed 11 October 2026')
    doc.add_paragraph(audience)
    doc.add_paragraph('This guide describes the implemented application and its evidence limits. Use the phase acceptance records for exact measured results and unresolved release gates.')
    doc.add_page_break()
    doc.add_paragraph('Contents', 'Title')
    field(doc.add_paragraph().add_run(), 'begin', ' TOC \\o "1-1" \\h \\z \\u ')
    field(doc.add_paragraph().add_run(), 'separate')
    for heading, _ in sections:
        entry = doc.add_paragraph(heading)
        entry.paragraph_format.space_after = Pt(3)
    entry = doc.add_paragraph('Source and revision evidence')
    entry.paragraph_format.space_after = Pt(3)
    field(doc.add_paragraph().add_run(), 'end')
    doc.add_page_break()
    for heading, paragraphs in sections:
        doc.add_heading(heading, 1)
        for paragraph in paragraphs:
            doc.add_paragraph(paragraph)
        if filename == 'DPH_User_Guide.docx' and heading == 'Learn the selected project':
            doc.add_page_break()
            doc.add_heading('The displayed learning pages', 2)
            doc.add_paragraph('These images are direct WebView2 captures from the running DPH test application, not proposed interface mockups. They show the visible portion of scrollable pages.')
            for image_name, caption in [
                ('rework-getting-started.png', 'Getting started: first-launch education before a project is loaded.'),
                ('rework-explain-browser.png', 'Explain: direct WebView2 capture for the synthetic semantics fixture. This is DPH rendering captured source evidence, not a screenshot of the analyzed application running.')
            ]:
                image_path = ROOT / 'docs' / image_name
                if not image_path.exists():
                    raise RuntimeError(f'Missing actual UI capture: {image_path}')
                doc.add_picture(str(image_path), width=Inches(5.0))
                doc.add_paragraph(caption)
            doc.add_page_break()
    doc.add_heading('Source and revision evidence', 1)
    doc.add_paragraph('The following source files and resources define this guide. SHA256 values identify the inspected implementation. Rebuild the guides after validated changes and retain the associated acceptance evidence.')
    evidence = []
    for source in sorted(ROOT.glob('DPH.*.pas')):
        evidence.append({'path': source.name, 'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
    for name in ['DPH.UI.Main.fmx', 'DelphiProjectHandoff.dpr', 'DelphiProjectHandoff.dproj']:
        source = ROOT / name
        evidence.append({'path': name, 'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
    for item in evidence:
        paragraph = doc.add_paragraph(item['path'])
        paragraph.paragraph_format.keep_with_next = True
        hash_paragraph = doc.add_paragraph(item['sha256'])
        hash_paragraph.paragraph_format.space_after = Pt(3)
        run = hash_paragraph.runs[0]
        run.font.name = 'Consolas'
        run.font.size = Pt(8)
    footer = section.footer.paragraphs[0]
    footer.add_run('DPH experimental software    ')
    field(footer.add_run(), 'begin', ' PAGE ')
    field(footer.add_run(), 'separate')
    footer.add_run('1')
    field(footer.add_run(), 'end')
    settings = doc.settings.element
    update = OxmlElement('w:updateFields')
    update.set(qn('w:val'), 'true')
    settings.append(update)
    output = GUIDES / filename
    doc.save(output)
    return evidence

required = {
    'DPH.UI.Main.pas': ['PublishClick', 'KnowledgeClick', 'DiscardKnowledgeClick', 'BrowserShouldLoad'],
    'DPH.Storage.Database.pas': ['SaveKnowledge', 'ReviewKnowledge', 'RecordExport', 'PublishGeneration'],
    'DPH.Publish.Export.pas': ['WriteGuide', 'Validate'],
    'DPH.Publish.Translation.pas': ['TranslateProse', 'Review'],
}
for filename, names in required.items():
    source = (ROOT / filename).read_text(encoding='utf-8-sig')
    for name in names:
        if name not in source:
            raise RuntimeError(f'Guide refers to an absent implementation: {filename}:{name}')

evidence = build('DPH_User_Guide.docx', 'DPH User Guide', 'For the person inspecting a Delphi project and recording its handoff knowledge', USER)
build('DPH_Engineering_Guide.docx', 'DPH Engineering Guide', 'For a Delphi developer building maintaining and validating DPH', ENGINEERING)
(ROOT / 'docs' / 'guide-source-validation.json').write_text(json.dumps({'guide_version': 4, 'sources': evidence, 'last_changed': '2026-10-11'}, indent=2), encoding='utf-8')
print('Created editable DPH user and engineering guides with source evidence and TOC fields')
